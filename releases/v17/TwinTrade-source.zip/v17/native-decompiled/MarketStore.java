package com.twintrade.app;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;
import java.util.UUID;
import org.java_websocket.extensions.ExtensionRequestData;
import org.java_websocket.framing.CloseFrame;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final class MarketStore {
    private static JSONObject book;
    private static Context context;
    private static long saved = 0;
    private static final TreeMap<Long, JSONObject> btc = new TreeMap<>();
    private static final TreeMap<Long, JSONObject> eth = new TreeMap<>();
    private static final HashMap<Integer, TreeMap<Long, JSONObject>> extra = new HashMap<>();
    private static final HashMap<Integer, Double> xprices = new HashMap<>();
    private static final HashMap<Integer, Long> xtimes = new HashMap<>();
    private static final double[] prices = {0.0d, 0.0d};
    private static final long[] times = {0, 0};
    static volatile String status = "Starting monitor";
    static volatile String historyStatus = "Loading Gains history";
    static volatile boolean running = false;

    public static synchronized void init(Context context2) {
        JSONArray jSONArrayOptJSONArray;
        if (context == null) {
            context = context2.getApplicationContext();
            try {
                String string = context.getSharedPreferences("market", 0).getString("book", ExtensionRequestData.EMPTY_VALUE);
                if (!string.isEmpty()) {
                    book = new JSONObject(string);
                }
                JSONObject jSONObject = new JSONObject(context.getSharedPreferences("market", 0).getString("candles", "{}"));
                for (int i = 0; i < 2; i++) {
                    JSONArray jSONArrayOptJSONArray2 = jSONObject.optJSONArray(ExtensionRequestData.EMPTY_VALUE + i);
                    if (jSONArrayOptJSONArray2 != null) {
                        merge(i, jSONArrayOptJSONArray2);
                    }
                }
                Iterator<String> itKeys = jSONObject.keys();
                while (itKeys.hasNext()) {
                    String next = itKeys.next();
                    try {
                        int i2 = Integer.parseInt(next);
                        if (i2 != 0 && i2 != 1 && (jSONArrayOptJSONArray = jSONObject.optJSONArray(next)) != null) {
                            merge(i2, jSONArrayOptJSONArray);
                        }
                    } catch (Exception e) {
                    }
                }
            } catch (Exception e2) {
            }
        }
    }

    private static TreeMap<Long, JSONObject> map(int i) {
        if (i == 0) {
            return btc;
        }
        if (i == 1) {
            return eth;
        }
        TreeMap<Long, JSONObject> treeMap = extra.get(Integer.valueOf(i));
        if (treeMap != null) {
            return treeMap;
        }
        TreeMap<Long, JSONObject> treeMap2 = new TreeMap<>();
        extra.put(Integer.valueOf(i), treeMap2);
        return treeMap2;
    }

    public static synchronized double priceOf(int i) {
        double dDoubleValue;
        if (i == 0) {
            dDoubleValue = prices[0];
        } else if (i == 1) {
            dDoubleValue = prices[1];
        } else {
            Double d = xprices.get(Integer.valueOf(i));
            dDoubleValue = d == null ? 0.0d : d.doubleValue();
        }
        return dDoubleValue;
    }

    public static synchronized long timeOf(int i) {
        long jLongValue;
        if (i == 0) {
            jLongValue = times[0];
        } else if (i == 1) {
            jLongValue = times[1];
        } else {
            Long l = xtimes.get(Integer.valueOf(i));
            jLongValue = l == null ? 0L : l.longValue();
        }
        return jLongValue;
    }

    private static int maxLev(int i) {
        if (i == 0) {
            return 200;
        }
        if (i == 1 || i == 300 || i == 313 || i == 327) {
            return 500;
        }
        return CloseFrame.NORMAL;
    }

    public static synchronized void seed(String str) {
        try {
            if (book == null) {
                book = new JSONObject(str);
                save(true);
            }
        } catch (Exception e) {
        }
    }

    public static synchronized String book() {
        String string;
        try {
            if (book == null) {
                book = new JSONObject("{\"cash\":100,\"positions\":[],\"history\":[]}");
            }
            string = book.toString();
        } catch (Exception e) {
            string = "{}";
        }
        return string;
    }

    public static synchronized void tick(int i, double d, long j) {
        if (i >= 0 && i <= 1000) {
            if (Double.isFinite(d) && d > 0.0d) {
                if (i == 0) {
                    prices[0] = d;
                    times[0] = j;
                } else if (i == 1) {
                    prices[1] = d;
                    times[1] = j;
                } else {
                    xprices.put(Integer.valueOf(i), Double.valueOf(d));
                    xtimes.put(Integer.valueOf(i), Long.valueOf(j));
                }
                long j2 = (j / 60000) * 60000;
                try {
                    TreeMap<Long, JSONObject> map = map(i);
                    JSONObject jSONObject = map.get(Long.valueOf(j2));
                    if (jSONObject == null) {
                        map.put(Long.valueOf(j2), new JSONObject().put("t", j2).put("o", d).put("h", d).put("l", d).put("c", d).put("source", "gains-live"));
                    } else {
                        jSONObject.put("h", Math.max(jSONObject.getDouble("h"), d)).put("l", Math.min(jSONObject.getDouble("l"), d)).put("c", d);
                    }
                    while (map.size() > 600) {
                        map.pollFirstEntry();
                    }
                    if (book != null) {
                        JSONArray jSONArray = book.getJSONArray("positions");
                        for (int length = jSONArray.length() - 1; length >= 0; length--) {
                            JSONObject jSONObject2 = jSONArray.getJSONObject(length);
                            if (jSONObject2.getInt("pair") == i && value(jSONObject2, d, j) <= ((-jSONObject2.getDouble("amount")) * jSONObject2.getJSONObject("cost").getDouble("liq")) / 100.0d) {
                                closeAt(jSONObject2, d, j, "Liquidated");
                            }
                        }
                    }
                    save(false);
                } catch (Exception e) {
                }
            }
        }
    }

    public static synchronized void merge(int i, JSONArray jSONArray) throws JSONException {
        TreeMap<Long, JSONObject> map = map(i);
        for (int i2 = 0; i2 < jSONArray.length(); i2++) {
            JSONObject jSONObject = jSONArray.getJSONObject(i2);
            long j = jSONObject.getLong("t");
            if (j >= 1000000000 && j < 1000000000000L) {
                j *= 1000;
            }
            long j2 = (j / 60000) * 60000;
            if (j2 > 0) {
                jSONObject.put("t", j2);
                if (!map.containsKey(Long.valueOf(j2)) || !"gains-live".equals(map.get(Long.valueOf(j2)).optString("source"))) {
                    map.put(Long.valueOf(j2), jSONObject);
                }
            }
        }
        while (map.size() > 600) {
            map.pollFirstEntry();
        }
    }

    public static synchronized void seedOhlc(int i, double d, double d2, double d3, double d4, long j) {
        if (i >= 0 && i <= 1000 && d > 0.0d && d2 > 0.0d && d3 > 0.0d && d4 > 0.0d) {
            try {
                long j2 = (j / 60000) * 60000;
                TreeMap<Long, JSONObject> map = map(i);
                JSONObject jSONObject = map.get(Long.valueOf(j2));
                if (jSONObject == null) {
                    map.put(Long.valueOf(j2), new JSONObject().put("t", j2).put("o", d).put("h", d2).put("l", d3).put("c", d4).put("source", "gains-charts"));
                } else if (!"gains-live".equals(jSONObject.optString("source"))) {
                    jSONObject.put("o", d).put("h", d2).put("l", d3).put("c", d4);
                }
                while (map.size() > 600) {
                    map.pollFirstEntry();
                }
            } catch (Exception e) {
            }
        }
    }

    public static synchronized String snapshot() {
        String string;
        try {
            JSONObject jSONObject = new JSONObject();
            JSONObject jSONObject2 = new JSONObject();
            JSONObject jSONObject3 = new JSONObject();
            for (Map.Entry<Integer, Double> entry : xprices.entrySet()) {
                jSONObject.put(String.valueOf(entry.getKey()), entry.getValue());
            }
            for (Map.Entry<Integer, Long> entry2 : xtimes.entrySet()) {
                jSONObject2.put(String.valueOf(entry2.getKey()), entry2.getValue());
            }
            for (Map.Entry<Integer, TreeMap<Long, JSONObject>> entry3 : extra.entrySet()) {
                jSONObject3.put(String.valueOf(entry3.getKey()), new JSONArray((Collection) entry3.getValue().values()));
            }
            string = new JSONObject().put("prices", new JSONArray(prices)).put("times", new JSONArray(times)).put("candles", new JSONArray().put(new JSONArray((Collection) btc.values())).put(new JSONArray((Collection) eth.values()))).put("pricesByPair", jSONObject).put("timesByPair", jSONObject2).put("candlesByPair", jSONObject3).put("status", status).put("history", historyStatus).put("running", running).toString();
        } catch (Exception e) {
            string = "{}";
        }
        return string;
    }

    public static synchronized void save(boolean z) {
        if (context != null && (z || System.currentTimeMillis() - saved >= 5000)) {
            saved = System.currentTimeMillis();
            JSONObject jSONObject = new JSONObject();
            try {
                jSONObject.put("0", new JSONArray((Collection) btc.values())).put("1", new JSONArray((Collection) eth.values()));
                for (Map.Entry<Integer, TreeMap<Long, JSONObject>> entry : extra.entrySet()) {
                    jSONObject.put(String.valueOf(entry.getKey()), new JSONArray((Collection) entry.getValue().values()));
                }
                SharedPreferences.Editor editorPutString = context.getSharedPreferences("market", 0).edit().putString("candles", jSONObject.toString());
                if (book != null) {
                    editorPutString.putString("book", book.toString());
                }
                if (z) {
                    editorPutString.commit();
                } else {
                    editorPutString.apply();
                }
            } catch (Exception e) {
            }
        }
    }

    private static double value(JSONObject jSONObject, double d, long j) throws JSONException {
        JSONObject jSONObject2 = jSONObject.getJSONObject("cost");
        double d2 = jSONObject.getDouble("amount") * jSONObject.getDouble("lev");
        double d3 = jSONObject.getBoolean("long") ? 1.0d : -1.0d;
        return (((d3 * d2) * ((((1.0d - ((jSONObject2.getDouble("slip") * d3) / 100.0d)) * d) / jSONObject.getDouble("entry")) - 1.0d)) - ((jSONObject2.getDouble("fee") * d2) / 50.0d)) - ((((d2 * (jSONObject2.getDouble("borrow") + (jSONObject2.getDouble("funding") * d3))) / 100.0d) * Math.max(0L, j - jSONObject.getLong("opened"))) / 3600000.0d);
    }

    private static void closeAt(JSONObject jSONObject, double d, long j, String str) throws JSONException {
        double d2 = jSONObject.getDouble("amount");
        double dMax = Math.max(-d2, value(jSONObject, d, j));
        JSONArray jSONArray = book.getJSONArray("positions");
        JSONArray jSONArray2 = new JSONArray();
        for (int i = 0; i < jSONArray.length(); i++) {
            if (!jSONArray.getJSONObject(i).getString("id").equals(jSONObject.getString("id"))) {
                jSONArray2.put(jSONArray.getJSONObject(i));
            }
        }
        book.put("positions", jSONArray2).put("cash", book.getDouble("cash") + Math.max(0.0d, d2 + dMax));
        jSONObject.put("net", dMax).put("exit", d).put("closed", j).put("status", str);
        JSONArray jSONArrayPut = new JSONArray().put(jSONObject);
        JSONArray jSONArray3 = book.getJSONArray("history");
        for (int i2 = 0; i2 < Math.min(199, jSONArray3.length()); i2++) {
            jSONArrayPut.put(jSONArray3.get(i2));
        }
        book.put("history", jSONArrayPut);
        save(true);
    }

    public static synchronized String open(int i, boolean z, double d, double d2, String str) throws Exception {
        String message;
        long jCurrentTimeMillis;
        try {
            book();
            jCurrentTimeMillis = System.currentTimeMillis();
        } catch (Exception e) {
            message = e.getMessage();
        }
        if (i < 0 || i > 1000 || jCurrentTimeMillis - timeOf(i) > 5000 || priceOf(i) <= 0.0d) {
            throw new Exception("Waiting for fresh Gains price");
        }
        if (!Double.isFinite(d) || d <= 0.0d || d > 100.0d || !Double.isFinite(d2) || d2 < 1.0d || d2 > maxLev(i)) {
            throw new Exception("Invalid percentage or leverage");
        }
        double dFloor = Math.floor(((book.getDouble("cash") * d) / 100.0d) * 1000000.0d) / 1000000.0d;
        if (dFloor <= 0.0d) {
            throw new Exception("No available paper collateral. Respawn to $100.");
        }
        JSONObject jSONObject = new JSONObject(str);
        JSONObject jSONObjectPut = new JSONObject().put("id", "p" + UUID.randomUUID()).put("pair", i).put("long", z).put("amount", dFloor).put("lev", d2).put("entry", priceOf(i) * ((((z ? 1 : -1) * jSONObject.getDouble("slip")) / 100.0d) + 1.0d)).put("opened", jCurrentTimeMillis).put("cost", jSONObject).put("status", "Paper open").put("kind", "paper");
        if (value(jSONObjectPut, priceOf(i), jCurrentTimeMillis) <= ((-dFloor) * jSONObject.getDouble("liq")) / 100.0d) {
            throw new Exception("Entry costs would liquidate this position");
        }
        book.getJSONArray("positions").put(jSONObjectPut);
        book.put("cash", book.getDouble("cash") - dFloor);
        save(true);
        message = "OK";
        return message;
    }

    public static synchronized String close(String str) {
        String message;
        try {
            JSONArray jSONArray = new JSONObject(book()).getJSONArray("positions");
            int i = 0;
            while (true) {
                if (i >= jSONArray.length()) {
                    message = "Position already closed";
                    break;
                }
                JSONObject jSONObject = jSONArray.getJSONObject(i);
                if (str.equals(jSONObject.getString("id"))) {
                    int i2 = jSONObject.getInt("pair");
                    if (System.currentTimeMillis() - timeOf(i2) > 5000) {
                        throw new Exception("Waiting for fresh Gains price");
                    }
                    closeAt(jSONObject, priceOf(i2), System.currentTimeMillis(), "Closed");
                    message = "OK";
                } else {
                    i++;
                }
            }
        } catch (Exception e) {
            message = e.getMessage();
        }
        return message;
        return message;
    }

    public static synchronized void reset() {
        try {
            book = new JSONObject("{\"cash\":100,\"positions\":[],\"history\":[]}");
            save(true);
        } catch (Exception e) {
        }
    }
}
