package com.twintrade.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Insets;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Process;
import android.security.keystore.KeyGenParameterSpec;
import android.util.Base64;
import android.view.View;
import android.view.WindowInsets;
import android.webkit.JavascriptInterface;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.security.KeyStore;
import java.util.HashMap;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import org.java_websocket.extensions.ExtensionRequestData;

/* loaded from: classes.dex */
public class MainActivity extends Activity {
    private WebView web;

    @Override // android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        MarketStore.init(this);
        getWindow().clearFlags(8192);
        getWindow().setStatusBarColor(-15262169);
        getWindow().setNavigationBarColor(-15393755);
        if (Build.VERSION.SDK_INT >= 30) {
            getWindow().setDecorFitsSystemWindows(false);
        } else {
            getWindow().getDecorView().setSystemUiVisibility(1792);
        }
        FrameLayout frameLayout = new FrameLayout(this);
        frameLayout.setBackgroundColor(-15393755);
        this.web = new WebView(this);
        frameLayout.addView(this.web, new FrameLayout.LayoutParams(-1, -1));
        setContentView(frameLayout);
        frameLayout.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() { // from class: com.twintrade.app.MainActivity$$ExternalSyntheticLambda0
            @Override // android.view.View.OnApplyWindowInsetsListener
            public final WindowInsets onApplyWindowInsets(View view, WindowInsets windowInsets) {
                return MainActivity.lambda$onCreate$0(view, windowInsets);
            }
        });
        frameLayout.requestApplyInsets();
        WebSettings settings = this.web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setMixedContentMode(1);
        this.web.addJavascriptInterface(new Vault(), "Vault");
        this.web.addJavascriptInterface(new Feed(), "Feed");
        this.web.setWebChromeClient(new AnonymousClass1());
        this.web.setWebViewClient(new WebViewClient() { // from class: com.twintrade.app.MainActivity.2
            @Override // android.webkit.WebViewClient
            public WebResourceResponse shouldInterceptRequest(WebView webView, WebResourceRequest webResourceRequest) throws IOException {
                if (!"app.twintrade.local".equals(webResourceRequest.getUrl().getHost())) {
                    return null;
                }
                try {
                    String path = webResourceRequest.getUrl().getPath();
                    if (path == null || path.equals("/")) {
                        path = "/index.html";
                    }
                    if (path.contains("..")) {
                        throw new IOException();
                    }
                    WebResourceResponse webResourceResponse = new WebResourceResponse(path.endsWith(".js") ? "application/javascript" : path.endsWith(".css") ? "text/css" : "text/html", "UTF-8", MainActivity.this.getAssets().open(path.substring(1)));
                    HashMap map = new HashMap();
                    map.put("Content-Security-Policy", "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; connect-src https: wss:; img-src 'self' data:; object-src 'none'; frame-src 'none'; base-uri 'none'");
                    webResourceResponse.setResponseHeaders(map);
                    return webResourceResponse;
                } catch (Exception e) {
                    return new WebResourceResponse("text/plain", "UTF-8", 404, "Not Found", null, new ByteArrayInputStream(new byte[0]));
                }
            }

            @Override // android.webkit.WebViewClient
            public boolean shouldOverrideUrlLoading(WebView webView, WebResourceRequest webResourceRequest) {
                return true;
            }
        });
        this.web.loadUrl("https://app.twintrade.local/index.html");
        if (getSharedPreferences("market", 0).getBoolean("keepAlive", true)) {
            startForegroundService(new Intent(this, (Class<?>) PriceMonitorService.class));
        }
        if (Build.VERSION.SDK_INT < 33 || checkSelfPermission("android.permission.POST_NOTIFICATIONS") == 0) {
            return;
        }
        requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 8);
    }

    static /* synthetic */ WindowInsets lambda$onCreate$0(View view, WindowInsets windowInsets) {
        if (Build.VERSION.SDK_INT >= 30) {
            Insets insets = windowInsets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
            view.setPadding(insets.left, insets.top, insets.right, Math.max(insets.bottom, windowInsets.getInsets(WindowInsets.Type.ime()).bottom));
            return WindowInsets.CONSUMED;
        }
        view.setPadding(windowInsets.getSystemWindowInsetLeft(), windowInsets.getSystemWindowInsetTop(), windowInsets.getSystemWindowInsetRight(), windowInsets.getSystemWindowInsetBottom());
        return windowInsets.consumeSystemWindowInsets();
    }

    /* renamed from: com.twintrade.app.MainActivity$1, reason: invalid class name */
    class AnonymousClass1 extends WebChromeClient {
        AnonymousClass1() {
        }

        @Override // android.webkit.WebChromeClient
        public boolean onJsConfirm(WebView webView, String str, String str2, final JsResult jsResult) {
            new AlertDialog.Builder(MainActivity.this).setMessage(str2).setPositiveButton("Confirm", new DialogInterface.OnClickListener() { // from class: com.twintrade.app.MainActivity$1$$ExternalSyntheticLambda0
                @Override // android.content.DialogInterface.OnClickListener
                public final void onClick(DialogInterface dialogInterface, int i) {
                    jsResult.confirm();
                }
            }).setNegativeButton("Cancel", new DialogInterface.OnClickListener() { // from class: com.twintrade.app.MainActivity$1$$ExternalSyntheticLambda1
                @Override // android.content.DialogInterface.OnClickListener
                public final void onClick(DialogInterface dialogInterface, int i) {
                    jsResult.cancel();
                }
            }).setOnCancelListener(new DialogInterface.OnCancelListener() { // from class: com.twintrade.app.MainActivity$1$$ExternalSyntheticLambda2
                @Override // android.content.DialogInterface.OnCancelListener
                public final void onCancel(DialogInterface dialogInterface) {
                    jsResult.cancel();
                }
            }).show();
            return true;
        }
    }

    @Override // android.app.Activity
    public void onBackPressed() {
        this.web.evaluateJavascript("if(document.getElementById('config').open)document.getElementById('config').close();else {document.getElementById('drawer').hidden=true;document.getElementById('shade').hidden=true;}", null);
    }

    public class Feed {
        public Feed() {
        }

        @JavascriptInterface
        public String snapshot() {
            return MarketStore.snapshot();
        }

        @JavascriptInterface
        public void seed(String str) {
            MarketStore.seed(str);
        }

        @JavascriptInterface
        public String paper() {
            return MarketStore.book();
        }

        @JavascriptInterface
        public String open(int i, boolean z, double d, double d2, String str) {
            return MarketStore.open(i, z, d, d2, str);
        }

        @JavascriptInterface
        public String close(String str) {
            return MarketStore.close(str);
        }

        @JavascriptInterface
        public void reset() {
            MarketStore.reset();
        }

        @JavascriptInterface
        public void keepAlive(boolean z) {
            MainActivity.this.getSharedPreferences("market", 0).edit().putBoolean("keepAlive", z).apply();
            if (z) {
                MainActivity.this.startForegroundService(new Intent(MainActivity.this, (Class<?>) PriceMonitorService.class));
            } else {
                MainActivity.this.stopService(new Intent(MainActivity.this, (Class<?>) PriceMonitorService.class));
            }
        }

        @JavascriptInterface
        public void batterySettings() {
            MainActivity.this.runOnUiThread(new Runnable() { // from class: com.twintrade.app.MainActivity$Feed$$ExternalSyntheticLambda1
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m0lambda$batterySettings$0$comtwintradeappMainActivity$Feed();
                }
            });
        }

        /* renamed from: lambda$batterySettings$0$com-twintrade-app-MainActivity$Feed, reason: not valid java name */
        /* synthetic */ void m0lambda$batterySettings$0$comtwintradeappMainActivity$Feed() {
            try {
                MainActivity.this.startActivity(new Intent("android.settings.IGNORE_BATTERY_OPTIMIZATION_SETTINGS"));
            } catch (Exception e) {
            }
        }

        @JavascriptInterface
        public void exitApp() {
            try {
                MainActivity.this.stopService(new Intent(MainActivity.this, (Class<?>) PriceMonitorService.class));
            } catch (Exception e) {
            }
            try {
                MainActivity.this.getSharedPreferences("market", 0).edit().putBoolean("keepAlive", false).apply();
            } catch (Exception e2) {
            }
            MainActivity.this.runOnUiThread(new Runnable() { // from class: com.twintrade.app.MainActivity$Feed$$ExternalSyntheticLambda0
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m1lambda$exitApp$2$comtwintradeappMainActivity$Feed();
                }
            });
        }

        /* renamed from: lambda$exitApp$2$com-twintrade-app-MainActivity$Feed, reason: not valid java name */
        /* synthetic */ void m1lambda$exitApp$2$comtwintradeappMainActivity$Feed() {
            try {
                MainActivity.this.finishAndRemoveTask();
            } catch (Exception e) {
                try {
                    MainActivity.this.finish();
                } catch (Exception e2) {
                }
            }
            try {
                new Handler().postDelayed(new Runnable() { // from class: com.twintrade.app.MainActivity$Feed$$ExternalSyntheticLambda2
                    @Override // java.lang.Runnable
                    public final void run() {
                        Process.killProcess(Process.myPid());
                    }
                }, 500L);
            } catch (Exception e3) {
            }
        }
    }

    public class Vault {
        public Vault() {
        }

        private SecretKey key() throws Exception {
            KeyStore keyStore = KeyStore.getInstance("AndroidKeyStore");
            keyStore.load(null);
            if (!keyStore.containsAlias("TwinTradeWallet")) {
                KeyGenerator keyGenerator = KeyGenerator.getInstance("AES", "AndroidKeyStore");
                keyGenerator.init(new KeyGenParameterSpec.Builder("TwinTradeWallet", 3).setBlockModes("GCM").setEncryptionPaddings("NoPadding").setRandomizedEncryptionRequired(true).build());
                keyGenerator.generateKey();
            }
            return (SecretKey) keyStore.getKey("TwinTradeWallet", null);
        }

        @JavascriptInterface
        public synchronized String save(String str) {
            String str2;
            if (str.matches("0x[0-9a-fA-F]{64}")) {
                try {
                    Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
                    cipher.init(1, key());
                    str2 = MainActivity.this.getSharedPreferences("vault", 0).edit().putString("wallet", new StringBuilder().append(Base64.encodeToString(cipher.getIV(), 2)).append(":").append(Base64.encodeToString(cipher.doFinal(str.getBytes("UTF-8")), 2)).toString()).commit() ? "OK" : "Storage failed";
                } catch (Exception e) {
                    str2 = "Key encryption failed";
                }
            } else {
                str2 = "Invalid key";
            }
            return str2;
        }

        @JavascriptInterface
        public synchronized String load() {
            String str;
            String string;
            try {
                string = MainActivity.this.getSharedPreferences("vault", 0).getString("wallet", ExtensionRequestData.EMPTY_VALUE);
            } catch (Exception e) {
                str = ExtensionRequestData.EMPTY_VALUE;
            }
            if (string.isEmpty()) {
                str = ExtensionRequestData.EMPTY_VALUE;
                return str;
            }
            String[] strArrSplit = string.split(":");
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(2, key(), new GCMParameterSpec(128, Base64.decode(strArrSplit[0], 2)));
            return new String(cipher.doFinal(Base64.decode(strArrSplit[1], 2)), "UTF-8");
        }

        @JavascriptInterface
        public synchronized void forget() {
            MainActivity.this.getSharedPreferences("vault", 0).edit().clear().commit();
            try {
                KeyStore keyStore = KeyStore.getInstance("AndroidKeyStore");
                keyStore.load(null);
                keyStore.deleteEntry("TwinTradeWallet");
            } catch (Exception e) {
            }
        }
    }
}
