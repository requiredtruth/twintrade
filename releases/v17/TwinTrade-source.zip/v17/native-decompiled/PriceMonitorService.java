package com.twintrade.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import org.java_websocket.client.WebSocketClient;
import org.java_websocket.handshake.ServerHandshake;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* loaded from: classes.dex */
public class PriceMonitorService extends Service {
    private static final int[] PAIRS = {0, 1, 300, 313};
    private WebSocketClient socket;
    private PowerManager.WakeLock wake;
    private final ScheduledExecutorService jobs = Executors.newScheduledThreadPool(2);
    private volatile boolean stopped = false;
    private volatile long lastFrame = 0;
    private volatile long lastConnect = 0;
    private volatile boolean historyBusy = false;

    private static String apiSymbol(int i) {
        if (i == 0) {
            return "BTC-USD";
        }
        if (i == 1) {
            return "ETH-USD";
        }
        if (i == 300) {
            return "BTCDEGEN-USD";
        }
        if (i == 313) {
            return "ETHDEGEN-USD";
        }
        return null;
    }

    /* renamed from: com.twintrade.app.PriceMonitorService$1, reason: invalid class name */
    class AnonymousClass1 extends WebSocketClient {
        AnonymousClass1(URI uri) {
            super(uri);
        }

        /* renamed from: lambda$onOpen$0$com-twintrade-app-PriceMonitorService$1, reason: not valid java name */
        /* synthetic */ void m3lambda$onOpen$0$comtwintradeappPriceMonitorService$1() {
            PriceMonitorService.this.history();
        }

        @Override // org.java_websocket.client.WebSocketClient
        public void onClose(int i, String str, boolean z) {
            MarketStore.status = "Disconnected · retrying";
        }

        @Override // org.java_websocket.client.WebSocketClient
        public void onError(Exception exc) {
            MarketStore.status = "Network unavailable · retrying";
        }

        @Override // org.java_websocket.client.WebSocketClient
        public void onMessage(String str) throws JSONException {
            JSONArray jSONArray;
            if (PriceMonitorService.this.socket != this) {
                return;
            }
            PriceMonitorService.this.lastFrame = System.currentTimeMillis();
            try {
                String strTrim = str.trim();
                if (strTrim.startsWith("{")) {
                    jSONArray = new JSONObject(strTrim).optJSONArray("m");
                    if (jSONArray == null) {
                        return;
                    }
                } else {
                    jSONArray = new JSONArray(strTrim);
                }
                if (jSONArray.length() > 1 && jSONArray.length() % 2 == 0) {
                    for (int i = 0; i < jSONArray.length(); i += 2) {
                        int i2 = jSONArray.getInt(i);
                        if (i2 >= 0 && i2 <= 1000) {
                            try {
                                MarketStore.tick(i2, jSONArray.getDouble(i + 1), PriceMonitorService.this.lastFrame);
                            } catch (Exception e) {
                            }
                        }
                    }
                }
            } catch (Exception e2) {
            }
        }

        @Override // org.java_websocket.client.WebSocketClient
        public void onOpen(ServerHandshake serverHandshake) {
            PriceMonitorService.this.lastFrame = System.currentTimeMillis();
            MarketStore.status = "Connected · background active";
            PriceMonitorService.this.jobs.execute(new Runnable() { // from class: com.twintrade.app.PriceMonitorService$1$$ExternalSyntheticLambda0
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.m3lambda$onOpen$0$comtwintradeappPriceMonitorService$1();
                }
            });
        }
    }

    /* renamed from: lambda$onCreate$0$com-twintrade-app-PriceMonitorService, reason: not valid java name */
    /* synthetic */ void m2lambda$onCreate$0$comtwintradeappPriceMonitorService() {
        if (this.stopped) {
            return;
        }
        try {
            long jCurrentTimeMillis = System.currentTimeMillis();
            if (this.socket == null || this.socket.isClosed() || (jCurrentTimeMillis - this.lastFrame > 20000 && jCurrentTimeMillis - this.lastConnect > 20000)) {
                connect();
            }
        } catch (Exception e) {
            MarketStore.status = "Reconnecting";
        }
    }

    @Override // android.app.Service
    public void onCreate() {
        super.onCreate();
        MarketStore.init(this);
        MarketStore.running = true;
        ((NotificationManager) getSystemService("notification")).createNotificationChannel(new NotificationChannel("prices", "Background market monitoring", 2));
        Notification notificationBuild = new Notification.Builder(this, "prices").setContentTitle("TwinTrade is monitoring markets").setContentText("Candles and paper positions continue in the background").setSmallIcon(android.R.drawable.ic_menu_recent_history).setContentIntent(PendingIntent.getActivity(this, 0, new Intent(this, (Class<?>) MainActivity.class), 201326592)).setOngoing(true).addAction(new Notification.Action.Builder((Icon) null, "Stop monitoring", PendingIntent.getService(this, 1, new Intent(this, (Class<?>) PriceMonitorService.class).setAction("STOP"), 201326592)).build()).build();
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(42, notificationBuild, 1073741824);
        } else {
            startForeground(42, notificationBuild);
        }
        this.wake = ((PowerManager) getSystemService("power")).newWakeLock(1, "TwinTrade:Prices");
        this.wake.acquire();
        this.jobs.scheduleWithFixedDelay(new Runnable() { // from class: com.twintrade.app.PriceMonitorService$$ExternalSyntheticLambda1
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.m2lambda$onCreate$0$comtwintradeappPriceMonitorService();
            }
        }, 0L, 3L, TimeUnit.SECONDS);
        this.jobs.execute(new PriceMonitorService$$ExternalSyntheticLambda0(this));
    }

    private synchronized void connect() {
        if (!this.stopped) {
            this.lastConnect = System.currentTimeMillis();
            if (this.socket != null) {
                this.socket.close();
            }
            MarketStore.status = "Connecting";
            try {
                this.socket = new AnonymousClass1(new URI("wss://backend-pricing.eu.gains.trade/v4"));
                this.socket.setConnectionLostTimeout(15);
                this.socket.connect();
            } catch (Exception e) {
                MarketStore.status = "Connection failed · retrying";
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void history() {
        boolean zFetchCandles;
        synchronized (this) {
            if (!this.historyBusy && !this.stopped) {
                this.historyBusy = true;
                try {
                    try {
                        zFetchCandles = fetchChartsSnapshot() | false;
                    } finally {
                        this.historyBusy = false;
                    }
                } catch (Exception e) {
                    zFetchCandles = false;
                }
                try {
                    for (int i : PAIRS) {
                        String strApiSymbol = apiSymbol(i);
                        if (strApiSymbol != null) {
                            try {
                                zFetchCandles |= fetchCandles(i, strApiSymbol, "polygon");
                            } catch (Exception e2) {
                                try {
                                    zFetchCandles |= fetchCandles(i, strApiSymbol, "arbitrum");
                                } catch (Exception e3) {
                                }
                            }
                        }
                    }
                    MarketStore.historyStatus = zFetchCandles ? "Gains history + live · 1m" : "History unavailable · cached/live candles shown";
                    if (!zFetchCandles && !this.stopped) {
                        this.jobs.schedule(new PriceMonitorService$$ExternalSyntheticLambda0(this), 30L, TimeUnit.SECONDS);
                    }
                } catch (Exception e4) {
                    MarketStore.historyStatus = "History unavailable · cached/live candles shown";
                    if (!this.stopped) {
                        this.jobs.schedule(new PriceMonitorService$$ExternalSyntheticLambda0(this), 30L, TimeUnit.SECONDS);
                    }
                }
            }
        }
    }

    private boolean fetchChartsSnapshot() throws Exception {
        int i;
        int i2;
        HttpURLConnection httpURLConnection = (HttpURLConnection) new URL("https://backend-pricing.eu.gains.trade/charts").openConnection();
        httpURLConnection.setConnectTimeout(15000);
        httpURLConnection.setReadTimeout(15000);
        try {
            if (httpURLConnection.getResponseCode() != 200) {
                throw new IOException("HTTP " + httpURLConnection.getResponseCode());
            }
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            InputStream inputStream = httpURLConnection.getInputStream();
            try {
                byte[] bArr = new byte[8192];
                while (true) {
                    int i3 = inputStream.read(bArr);
                    i = 0;
                    if (i3 == -1) {
                        break;
                    }
                    byteArrayOutputStream.write(bArr, 0, i3);
                }
                if (inputStream != null) {
                    inputStream.close();
                }
                JSONObject jSONObject = new JSONObject(byteArrayOutputStream.toString("UTF-8"));
                JSONArray jSONArray = jSONObject.getJSONArray("opens");
                JSONArray jSONArray2 = jSONObject.getJSONArray("highs");
                JSONArray jSONArray3 = jSONObject.getJSONArray("lows");
                JSONArray jSONArray4 = jSONObject.getJSONArray("closes");
                long jCurrentTimeMillis = System.currentTimeMillis();
                int iMin = Math.min(Math.min(jSONArray.length(), jSONArray2.length()), Math.min(jSONArray3.length(), jSONArray4.length()));
                boolean z = false;
                while (i < iMin && i <= 1000) {
                    if (jSONArray.isNull(i) || jSONArray2.isNull(i) || jSONArray3.isNull(i)) {
                        i2 = iMin;
                    } else if (jSONArray4.isNull(i)) {
                        i2 = iMin;
                    } else {
                        try {
                            i2 = iMin;
                            try {
                                MarketStore.seedOhlc(i, jSONArray.getDouble(i), jSONArray2.getDouble(i), jSONArray3.getDouble(i), jSONArray4.getDouble(i), jCurrentTimeMillis);
                                z = true;
                            } catch (Exception e) {
                            }
                        } catch (Exception e2) {
                        }
                    }
                    i++;
                    iMin = i2;
                }
                return z;
            } finally {
            }
        } finally {
            httpURLConnection.disconnect();
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r21v0, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r21v1 */
    /* JADX WARN: Type inference failed for: r21v2, types: [java.net.HttpURLConnection] */
    /* JADX WARN: Type inference failed for: r21v3 */
    /* JADX WARN: Type inference failed for: r21v5 */
    /* JADX WARN: Type inference failed for: r21v6 */
    /* JADX WARN: Type inference failed for: r21v9 */
    private boolean fetchCandles(int i, String str, String str2) throws Exception {
        Throwable th;
        int i2;
        long jCurrentTimeMillis = System.currentTimeMillis();
        HttpURLConnection httpURLConnection = (HttpURLConnection) new URL("https://api.gains.trade/v1/" + str2 + "/markets/" + ((String) str) + "/candles?interval=1m&from=" + (jCurrentTimeMillis - 18000000) + "&to=" + jCurrentTimeMillis).openConnection();
        httpURLConnection.setConnectTimeout(15000);
        httpURLConnection.setReadTimeout(15000);
        try {
            try {
                if (httpURLConnection.getResponseCode() != 200) {
                    throw new IOException("HTTP " + httpURLConnection.getResponseCode());
                }
                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                InputStream inputStream = httpURLConnection.getInputStream();
                try {
                    byte[] bArr = new byte[8192];
                    while (true) {
                        int i3 = inputStream.read(bArr);
                        i2 = 0;
                        if (i3 == -1) {
                            break;
                        }
                        try {
                            byteArrayOutputStream.write(bArr, 0, i3);
                        } catch (Throwable th2) {
                            th = th2;
                            str = httpURLConnection;
                            if (inputStream == null) {
                                throw th;
                            }
                            try {
                                inputStream.close();
                                throw th;
                            } catch (Throwable th3) {
                                th.addSuppressed(th3);
                                throw th;
                            }
                        }
                    }
                    if (inputStream != null) {
                        inputStream.close();
                    }
                    JSONArray jSONArray = new JSONObject(byteArrayOutputStream.toString("UTF-8")).getJSONArray("data");
                    JSONArray jSONArray2 = new JSONArray();
                    while (i2 < jSONArray.length()) {
                        JSONObject jSONObject = jSONArray.getJSONObject(i2);
                        double d = jSONObject.getDouble("open");
                        double d2 = jSONObject.getDouble("high");
                        double d3 = jSONObject.getDouble("low");
                        double d4 = jSONObject.getDouble("close");
                        long j = jSONObject.getLong("time");
                        if (j >= 1000000000 && j < 1000000000000L) {
                            j *= 1000;
                        }
                        HttpURLConnection httpURLConnection2 = httpURLConnection;
                        JSONArray jSONArray3 = jSONArray;
                        long j2 = (j / 60000) * 60000;
                        if (j2 > 0 && j2 <= jCurrentTimeMillis && Double.isFinite(d) && Double.isFinite(d2) && Double.isFinite(d3) && Double.isFinite(d4) && d3 > 0.0d && d2 >= Math.max(d, d4) && d3 <= Math.min(d, d4)) {
                            jSONArray2.put(new JSONObject().put("t", j2).put("o", d).put("h", d2).put("l", d3).put("c", d4).put("source", "gains-history"));
                        }
                        i2++;
                        httpURLConnection = httpURLConnection2;
                        jSONArray = jSONArray3;
                    }
                    HttpURLConnection httpURLConnection3 = httpURLConnection;
                    MarketStore.merge(i, jSONArray2);
                    MarketStore.save(true);
                    httpURLConnection3.disconnect();
                    return true;
                } catch (Throwable th4) {
                    str = httpURLConnection;
                    th = th4;
                }
            } catch (Throwable th5) {
                th = th5;
                str.disconnect();
                throw th;
            }
        } catch (Throwable th6) {
            th = th6;
            str = httpURLConnection;
        }
    }

    @Override // android.app.Service
    public int onStartCommand(Intent intent, int i, int i2) {
        if (intent == null || !"STOP".equals(intent.getAction())) {
            return 1;
        }
        getSharedPreferences("market", 0).edit().putBoolean("keepAlive", false).apply();
        stopSelf();
        return 2;
    }

    @Override // android.app.Service
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override // android.app.Service
    public void onDestroy() {
        this.stopped = true;
        MarketStore.running = false;
        MarketStore.status = "Monitoring stopped";
        if (this.socket != null) {
            this.socket.close();
        }
        this.jobs.shutdownNow();
        MarketStore.save(true);
        if (this.wake != null && this.wake.isHeld()) {
            this.wake.release();
        }
        super.onDestroy();
    }
}
