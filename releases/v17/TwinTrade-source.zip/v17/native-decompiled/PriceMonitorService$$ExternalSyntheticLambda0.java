package com.twintrade.app;

/* compiled from: D8$$SyntheticClass */
/* loaded from: classes.dex */
public final /* synthetic */ class PriceMonitorService$$ExternalSyntheticLambda0 implements Runnable {
    public final /* synthetic */ PriceMonitorService f$0;

    public /* synthetic */ PriceMonitorService$$ExternalSyntheticLambda0(PriceMonitorService priceMonitorService) {
        this.f$0 = priceMonitorService;
    }

    @Override // java.lang.Runnable
    public final void run() {
        this.f$0.history();
    }
}
