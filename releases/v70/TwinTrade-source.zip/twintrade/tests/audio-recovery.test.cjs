const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict'),path=require('node:path');
const stored={},nodes={},texts=[],strokes=[],events={};
const ctx=new Proxy({fillText:s=>texts.push(s),moveTo:(x,y)=>strokes.push({x,y}),measureText:s=>({width:s.length*5})},{get:(o,k)=>o[k]||(()=>{})});
const node=id=>nodes[id]??={value:({amount:'10',lev:'100'})[id]||'',checked:true,hidden:true,textContent:'',innerHTML:'',getBoundingClientRect:()=>({width:393,height:400}),getContext:()=>ctx,addEventListener(){},setAttribute(){}};
function boot(native=null){const env={console,document:{hidden:false,getElementById:node,querySelector:()=>node('dismiss'),querySelectorAll:()=>[],addEventListener:(e,f)=>events[e]=f},localStorage:{getItem:k=>stored[k]||null,setItem:(k,v)=>stored[k]=v},setTimeout:()=>0,clearTimeout(){},setInterval(){},devicePixelRatio:1,confirm:()=>false,addEventListener(){},WebSocket:class{constructor(){this.readyState=1}close(){this.readyState=3}},ethers:{providers:{JsonRpcProvider:class{}},Contract:class{}},AbortController,fetch:async()=>{throw Error('offline')},GABI:[]};env.window=env;if(native)env.NativeAudio=native;Object.assign(env,{URL,clearInterval:()=>{}});vm.createContext(env);for(const f of ['config.js','engine.js','trade-state.js','market-data.js','routing.js','app.js'])vm.runInContext(fs.readFileSync(path.join(__dirname,'../app/src/main/assets',f),'utf8'),env);return {env,run:c=>vm.runInContext(c,env)}}
(async()=>{const {run,env}=boot();await new Promise(r=>setImmediate(r));
let created=0,resumes=0,started=0,reject=false;
env.AudioContext=class {constructor(){created++;this.state='suspended';this.currentTime=0;this.destination={}}resume(){resumes++;if(reject)return Promise.reject(Error('interrupted'));this.state='running';return Promise.resolve()}createOscillator(){return {frequency:{value:0},connect(){},start(){started++},stop(){}}}createGain(){return {gain:{setValueAtTime(){},exponentialRampToValueAtTime(){}},connect(){}}}};
run('ensureAudio()');assert.equal(created,1);assert.equal(run('audioCtx.state'),'running');
run("audioCtx.state='interrupted';onAppResume()");assert.equal(run('audioCtx.state'),'running');assert.equal(resumes,2);
run("audioCtx.state='closed';ensureAudio()");assert.equal(created,2);
reject=true;run("audioCtx.state='suspended';ensureAudio()");await new Promise(r=>setImmediate(r));assert.match(run('audioError'),/retry/,'resume rejection is handled');
reject=false;run('ensureAudio()');await new Promise(r=>setImmediate(r));assert.equal(run('audioError'),'');
run('soundOn=false;tickOn=false;persist()');const before=resumes;run("audioCtx.state='suspended';onAppResume()");assert.equal(resumes,before,'mute preference does not resume audio');
node('enableAudio').onclick();assert.equal(run('soundOn&&tickOn'),true);assert(started>0,'enable plays confirmation tones');assert.equal(stored.soundOn,'true');assert.equal(stored.tickOn,'true');assert.match(node('audioStatus').textContent,/Events on.*running/);
node('mute').onclick();assert.equal(run('soundOn||tickOn'),false);const muted=started;run("eventSound('public-open-long');onTick(100,101)");assert.equal(started,muted,'saved mute silences event and tick tones');node('mute').onclick();assert(started>muted,'unmute produces confirmation');
run('priceSoundSuppressedUntil=0;lastTickAt=0');const small=started;run('onTick(100000,100000.1)');assert(started>small,'small real price moves produce tones');run('lastTickAt=0');const flat=started;run('onTick(100000,100000)');assert.equal(started,flat,'unchanged quotes remain silent');
assert.equal(run('softTickFrequency(5000)'),1080);assert.equal(run('softTickFrequency(20)'),220);assert.equal(run('softTickFrequency(620)'),620);
const gentle=run("soundProfile='gentle';profiledEventNotes(EVENT_SOUND_PALETTE['public-open-long'])"),warm=run("soundProfile='warm';profiledEventNotes(EVENT_SOUND_PALETTE['public-open-long'])"),minimal=run("soundProfile='minimal';profiledEventNotes(EVENT_SOUND_PALETTE['public-open-long'])");assert.equal(gentle.length,3);assert.equal(warm.length,3);assert.equal(minimal.length,2);assert(Math.abs(warm[0][0]/gentle[0][0]-.88)<.0001);assert(warm.every(n=>n[2]!=='chime'));assert(minimal.every(n=>n[3]<gentle[0][3]));run('soundLevel=.45;persist()');assert.equal(stored.soundProfile,'"minimal"','sound character persists');assert.equal(stored.soundLevel,'0.45','sound level persists');
const preview=run('SOUND_PREVIEW_SEQUENCE.map(x=>x[0])');assert(preview.includes('pnl-profit')&&preview.includes('pnl-loss'),'preview routes current profit/loss crossing cues');assert(!preview.includes('cross-up')&&!preview.includes('cross-down'),'preview has no removed crossing names');assert.equal(run('SOUND_PREVIEW_GAP_MS'),560);const upPreview=run("EVENT_SOUND_PALETTE['preview-tick-up']"),downPreview=run("EVENT_SOUND_PALETTE['preview-tick-down']");assert(Math.max(...upPreview.concat(downPreview).map(n=>n[0]))<700,'preview movement cues avoid piercing test tones');stored.soundLevel='2';const fallback=boot();assert.equal(fallback.run('soundLevel'),1,'invalid saved level falls back to full');stored.soundLevel='0.45';
assert(preview.includes('my-liq-long')&&preview.includes('my-liq-short')&&!preview.includes('my-liq'),'preview exposes distinct owner liquidation sides');assert.notDeepEqual(run("EVENT_SOUND_PALETTE['my-liq-long']"),run("EVENT_SOUND_PALETTE['my-liq-short']"),'owner liquidation side phrases differ');
run("soundProfile='gentle';lastTickAt=0;eventSound('public-open-long')");const eventCount=started;run('lastTickAt=0;onTick(100,101);onCandleClose({o:100,c:101})');assert.equal(started,eventCount,'event phrase suppresses overlapping tick and candle sounds');run('priceSoundSuppressedUntil=0;lastTickAt=0;onTick(101,102)');assert(started>eventCount,'movement sound resumes after the phrase');
const candleTones=[];env.tone=(...args)=>candleTones.push(args);run(`priceSoundSuppressedUntil=0;lastCandleSoundAt=0;lastTickAt=0;tickOn=true;mode='paper';pair=0;book={cash:100,positions:[],history:[]};prices[0]=100;candles[0]=[{t:Math.floor(Date.now()/60000)*60000-60000,o:99,h:101,l:98,c:100,source:'gains-live'}];setPrice(0,100.1,Date.now())`);assert.equal(candleTones.length,2,'minute rollover plays one candle phrase instead of stacking a tick');assert(candleTones.every(n=>['warm','chime'].includes(n[2])&&n[0]>=220&&n[0]<=700&&n[3]<=.052),'foreground candle phrase is gentle and bounded');
function shortNotes(prev,next,bar=false){
 candleTones.length=0;
 run(`priceSoundSuppressedUntil=0;lastTickAt=0;lastCandleSoundAt=0;tickMotionState=null;prices[0]=100;book.positions=[Engine.open(0,false,10,10,120,{fee:0,slip:0,borrow:0,funding:0,liq:90},Date.now())];${bar?`onCandleClose({o:${prev},c:${next}})`:`onTick(${prev},${next})`}`);
 return candleTones.map(n=>n[0]);
}
for(const bar of [false,true]){
 const adverse=shortNotes(100,100.5,bar),favorable=shortNotes(100,99.5,bar);
 assert(adverse.length>=2&&adverse.every((f,i)=>i===0||f<adverse[i-1]),'rising price descends for a profitable short');
 assert(favorable.length>=2&&favorable.every((f,i)=>i===0||f>favorable[i-1]),'falling price ascends for a profitable short');
}
const crossings=[];env.eventSound=k=>crossings.push(k);env.pushEvent=()=>{};run("mode='live';pair=0;fullyLoaded=true;soundOn=true;livePositions=[{id:'short',pair:0,long:false,entry:100,liq:150,_xAt:-1e15}];lastCrossAt=0;checkCrossings(101,99);livePositions[0]._xAt=-1e15;lastCrossAt=0;checkCrossings(99,101)");assert.deepEqual(crossings,['pnl-profit','pnl-loss'],'short entry crossings use profit/loss semantics rather than raw price direction');
const calls=[],bridge={enabled:v=>calls.push(['enabled',v]),status:()=> 'running',clearPending:()=>calls.push(['clear']),tone:(...a)=>calls.push(['tone',...a])};const apk=boot(bridge);await new Promise(r=>setImmediate(r));apk.run('soundOn=true;tickOn=true;soundLevel=.45;tone(660,.1,"triangle",.095,.05)');const scaled=calls.find(c=>c[0]==='tone'&&c[1]===660);assert(scaled&&Math.abs(scaled[4]-.04275)<1e-9,'APK native PCM receives scaled gain');apk.run("eventSound('public-open-long')");assert(calls.some(c=>c[0]==='clear'),'APK event phrase clears queued movement tones');apk.run('soundOn=false;tickOn=false;renderAudioStatus()');assert.deepEqual(calls.at(-1),['enabled',false]);
const liquidation=apk.run("EVENT_SOUND_PALETTE['my-liq-long']");
assert(liquidation.every(n=>n[2]==='buzzer'&&n[3]>.2)&&liquidation[0][0]>liquidation[1][0],'liquidation uses a loud descending buzzer');
assert.equal(apk.run("EVENT_SOUND_PALETTE['my-close-loss'].length"),1);
assert.equal(apk.run("EVENT_SOUND_PALETTE['my-close-win'].length"),7);
assert.equal(apk.run("eventCueDuration('my-liq-long')"),5);
const cueTimers=[];
apk.env.setTimeout=(callback,delay)=>cueTimers.push({callback,delay});
calls.length=0;
apk.run("soundOn=true;eventSound('my-close-win');eventSound('my-close-win');eventSound('my-close-win')");
for(let count=1;count<=3;count++){
 assert.equal(calls.filter(call=>call[0]==='tone').length,7*count,'one full fanfare per queued win');
 const timer=cueTimers.shift();
 assert(timer.delay>=990,'fanfares wait until the previous phrase ends');
 timer.callback();
}
apk.run("closeRequestCue(10);closeRequestCue(-10)");
assert.equal(calls.filter(call=>call[0]==='tone').at(-1)[3],'chime');
cueTimers.shift().callback();
assert.equal(calls.filter(call=>call[0]==='tone').at(-1)[3],'buzzer');
assert.equal(apk.run("evaluateExit({pair:0,long:true,exits:{tp:110}},110,Date.now())"),'Take profit');
assert.equal(apk.run("evaluateExit({pair:0,long:false,exits:{sl:110}},110,Date.now())"),'Stop loss');
assert.equal(apk.run("evaluateExit({pair:0,long:true,exits:{trail:5,best:120}},113,Date.now())"),'Trailing exit');
assert.equal(apk.run("(()=>{const t=Math.floor(Date.now()/60000)*60000;candles[0]=Array.from({length:15},(_,i)=>({t:t-(15-i)*60000,h:111,l:109,c:110}));return evaluateExit({pair:0,long:true,exits:{atr:3}},104,t)})()"),'Chandelier exit');
const native=fs.readFileSync(path.join(__dirname,'../app/src/main/java/com/twintrade/app/MainActivity.java'),'utf8');assert(native.includes('setMediaPlaybackRequiresUserGesture(false)'));assert(native.includes("getElementById('chartInfoDialog').close()"));
console.log('PASS: interrupted/suspended/closed audio recovery, handled resume failure, saved mute, enable/test and audible unmute confirmation.');})();
