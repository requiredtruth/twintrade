# TwinTrade 0.64.0

Android and standalone browser trading terminal reconstructed from the supplied v17 APK. Paper mode is the default; Android live trading uses Polygon native USDC and requires POL for gas.

## Releases

- v0.64.0: durable paper execution queue for opens, individual/bulk closes and liquidations; independently persisted 3–10 second delays with a 5% 30-second outlier, reserved collateral, duplicate guards, visible countdowns and execution-time pricing. Live Polygon timing is unchanged.
- v0.63.0: idempotent timestamped background candle replay and selected-market native catch-up.

- v0.62.0: chart Legend beside Stats/L/S/Chart with actual line colors, patterns, entry/liquidation meanings and nearest leverage-band definitions.
- v0.61.0: high-priority event and candle cues now flush already-buffered native movement PCM before starting, eliminating residual overlap tails.

- v0.60.0: owner paper liquidations now use distinct long/short profiled phrases in both foreground and Android background playback.

- v0.59.0: minute-close cues now use gentle mood-aware warm/chime phrases with foreground/background parity and replace the boundary tick instead of overlapping it.

- v0.58.0: production directional ticks now use bounded 220–1080 Hz warm/chime phrases with at most three notes across web and Android background playback.
- v0.57.0: sound preview now routes the current profit/loss crossing cues, prevents duplicate preview runs, spaces phrases to avoid overlap, and uses gentle tick examples.
- v0.56.0: entry-line cues now describe profit versus loss for both long and short positions, with matching foreground and Android background playback, two-second anti-repeat control and event overlap suppression.
- v0.55.0: persistent Soft, Balanced and Full sound levels scale event, price and candle cues consistently in the browser, APK foreground and Android background service.

- v0.54.0: execution and liquidation phrases now preempt queued price/candle tones and reserve a short quiet window, preventing category overlap while direction state continues updating.

- v0.53.0: optional Gentle, Warm and Minimal event-sound characters persist across sessions and remain consistent between foreground WebAudio/native PCM and Android background playback.

- v0.52.0: gentler warm/chime synthesis, distinct long/short/open/close/LIQ and profit/loss phrases, quieter micro-tick cadence, and liquidation-first background burst arbitration.

- v0.51.0: optional per-stream diagnostics distinguish the price oracle from Polygon, Arbitrum and Base trade streams, showing valid-data age, retry state and a bounded reconnect history without changing execution behavior.

- v0.50.0: correct side-specific legacy + v2 borrowing estimates, separate funding/borrowing amounts, forward recovery of paper fallback rates, independent live fee reads; softer tick/tock micro-move sounds and native background audio/execution activity until Stop/Exit.

- v0.49.0: native background recovery uses usable price frames, elapsed-time deadlines, capped outage backoff and obsolete-callback protection; stopping monitoring shuts down immediately. Includes the three-network trade-stream reconnect fix.

- [Original source beta](https://github.com/requiredtruth/twintrade/releases/tag/v0.3.0-beta): supplied source ZIP preserved unchanged.
- [Supplied v17](https://github.com/requiredtruth/twintrade/releases/tag/v0.17.0-supplied): original APK preserved unchanged, exact extracted web assets and native dissection.
- v0.20.0: reconstructed native source, corrected live approval, explicit order review, fresh index quotes, bounded receipt waits, reconnect watchdog, market-specific history loading, validated candles/costs and dynamic market limits.
- v0.47.0: added right-side candle spacing and corrected horizontal drag direction; time labels stay aligned across zoom and rotation.
- v0.46.0: sounds on every changed quote, with a 90ms rate limit. Android uses native PCM sonification with short ducking focus requests, automatic recovery after another app plays audio, and preserved mute preferences.
- v0.45.0: L/S button beside Stats opens total and leverage-tier ratios in a dialog.
- v0.44.0: Chart button beside Stats opens the current range/zoom/interval/timezone dialog. Candle time labels remain below the chart. Audio recovers on resume/interruption, with a sound status and explicit enable/test control.
- v0.43.0: local time/date axis and history loading on gesture zoom.
- v0.42.0: live opens and closes require a synchronized mark/index frame before review and again immediately before contract simulation or submission.
- v0.48.0: confirmed transactions whose oracle order event cannot be decoded reconcile from exact resulting position state instead of blocking the wallet journal forever.

Each release has APK, self-contained HTML, source ZIP, spec.md and SHA256SUMS. See spec.md and V17-AUDIT.md for provenance and validation limits. No funded trade or physical Android-device test was performed. This is a client of Gains/Polygon services; outages can pause trading.

## Build and test

JDK 17+, Node and Python 3 are required.

```sh
./install.sh
./test.sh
./build.sh
./run.sh
```

Set ANDROID_SDK_ROOT for an existing SDK with Android 35 and build-tools 35.0.0. APK: dist/TwinTrade.apk. Browser file: dist/TwinTrade.html. `./cli.sh test`, `./cli.sh build` and `./cli.sh web` expose the same workflows. CI also runs real Chromium layout and rotation checks.

The browser version supports paper trading and public data. Private-key persistence/live signing requires the Android Keystore bridge. It does not silently store keys in browser localStorage.

## APK installation

The supplied v17 APK uses its original certificate. This rebuilt release uses a different certificate. Installing over the original will fail; preserve your wallet recovery material and paper records before uninstalling it. No wallet or signing private keys are included in the repository or public release. Release builds require the preserved private `build/signing.jks` and fail rather than silently rotating the certificate.

0.20.0 adds stable public trade tracking, reset chart, bold high-leverage averages, 30-second desync warnings and all-market Portfolio / Past trades menu pages. Confirmed live history import covers the backend's past-24h window; missing settlements remain unavailable.

0.21.0 repairs candle gaps with history reconciliation and marked placeholders, aligns own chart labels with net P&L, separates opening/closing fees, and labels holding gains/losses. Paper estimates preserve their entry assumptions; live closing costs remain estimates until settlement.

0.22.0 removes repeating near-LIQ alerts, adds a live Stats popup, fixes own live liquidation lines and stale connection callbacks, and caches unchanged chart averages.

0.23.0 restores foreground prices when Android background monitoring is stopped, writes recovery quotes into the native ledger, and adds price-transport diagnostics and manual reconnection under Stats.

0.25.0 removes the chart-shifting green Ready bar, moves transient sync messages above borrowing text, fixes retry/request races and preserves spread metadata, and reuses unchanged DOM.

0.27.0 shortens sides to L/S and trade sizes/leverage to whole numbers, adds a Zoom submenu with 10m–1w range and 1m–1d OHLC candles, shows BTCDEGEN public trades on BTC, draws every displayed public position’s known or estimated LIQ, and retains the chart on app return.

Startup regression: `bash tests/android-startup.sh releases/v27/TwinTrade.apk` with a connected Android 15 emulator.

0.28.0 targets missing candle ranges beyond the latest five hours, retains successful history pages, tries alternate Gains history for incomplete ranges, and uses one bounded repair timer with outage backoff. Native monitoring no longer forks retry chains.

0.29.0 adds persistent close-detail dialogs with saved paper settlement receipts and a Close menu beside Positions: all/longs/shorts for the current coin or all coins. Holding costs and both fees are already included in net P&L; receipts show every deduction and cash returned.

0.30.0 locks wallet, node and mode changes for the entire close batch and requires successful wallet reconciliation between live closes. Builds refuse to rotate a missing private release key.

0.31.0 reduces repeated Android bridge/history/chart work, yields large sync calculations, bounds failed variable refreshes and adds a detailed loading progress overlay at the top of the chart.

Background refreshes and retries stay quiet; progress is shown for startup and explicit user loads only.

0.33.0 combines BTC and BTCDEGEN in the BTC view. Leverage above the regular BTC cap executes on BTCDEGEN, with its own fresh quotes and fees. Your BTC and BTCDEGEN positions and liquidation lines remain visible together.

0.34.0 waits for the execution market’s holding rates before saving new paper positions, shows leveraged hourly costs/credits, and fixes vertical panning so distant public entries and liquidation lines appear as they enter view.

0.35.0 adds six distinct public execution sounds (OPEN/CLOSE/LIQ × L/S) and a replacing chart-top event banner in the loading-overlay position. Alerts follow the current chart, including BTCDEGEN on BTC; historical snapshots stay quiet and duplicate socket/contract reports are suppressed.

0.36.0 keeps the latest trade banner until replacement, including chart switches and session recreation, and verifies entry/LIQ line changes through all three live socket callbacks. Closed metadata no longer suppresses a new open sound.

0.37.0 shows public execution messages/sounds for all markets and seeds a silent, timestamped last confirmed trade at startup. Live alerts no longer wait for snapshots/history; chart lines remain scoped to the selected market.

0.38.0 scopes execution text, startup history and sounds to the selected chart (BTC includes BTCDEGEN), with silent matching event restoration when switching charts.

### 0.39.0 leverage controls

Type an exact leverage (including 1.1×) or use Quick ×. The label shows the selected market’s current minimum and maximum; quick choices always include both endpoints. 150× and 250× markets no longer stop at the old 100× preset.

### 0.40.0 exact allowance verification

Live opens reduce any different USDC allowance to the exact collateral amount, verify the confirmed on-chain allowance before simulation/submission, and stop without submitting an order if verification differs. Replacement approval transaction hashes are saved for reliable reconciliation.


## 0.65.0

Shared network failover and fee-source validation from Rough Path Alpha are integrated without its indicator or bot. Account-wide balance/margin P&L percentages, active margin and open-trade count sit under top net P&L. See [integration audit](MERGE-AUDIT.md).

## 0.66.0

Adds the Profile performance chart and closed-trade analytics, including Sharpe/Sortino, to the 0.65.0 integration. Ratio definitions and available-history limits are shown inside the panel.
