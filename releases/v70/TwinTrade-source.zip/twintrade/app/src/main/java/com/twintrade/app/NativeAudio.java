package com.twintrade.app;

import android.content.Context;
import android.media.*;
import android.os.*;
import android.webkit.JavascriptInterface;
import java.util.ArrayList;

/** Short sonification bursts, independent of Chromium's media focus/session. */
public final class NativeAudio {
 private static final int RATE=24000, BLOCK=480;
 private final HandlerThread thread=new HandlerThread("TwinTradeAudio");
 private final Handler handler;
 private final AudioManager manager;
 private final AudioAttributes attributes=new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build();
 private final AudioFocusRequest focus;
 private final ArrayList<Note> notes=new ArrayList<>();
 private AudioTrack track;
 private boolean foreground=false,enabled=false,focused=false,pumping=false,waiting=false;
 private long cursor=0,lastHead=0,drainDeadline=0;
 private volatile String state="ready";
 private volatile long playedFrames=0;
 private final Runnable pump=this::pump;
 private final Runnable idle=this::finishBurst;
 private static final class Note {
  final double frequency,gain;final String type;final long start,end;
  Note(double f,double g,String t,long s,long e){frequency=f;gain=g;type=t;start=s;end=e;}
 }
 public NativeAudio(Context context){
  manager=(AudioManager)context.getSystemService(Context.AUDIO_SERVICE);
  thread.start();handler=new Handler(thread.getLooper());
  focus=new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK).setAudioAttributes(attributes).setOnAudioFocusChangeListener(change->{
   if(!foreground||!enabled)return;
   if(change==AudioManager.AUDIOFOCUS_GAIN){focused=true;waiting=false;if(track!=null)track.setVolume(1);state="ready";}
   else if(change==AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK){if(track!=null)track.setVolume(.25f);}
   else {waiting=change==AudioManager.AUDIOFOCUS_LOSS_TRANSIENT;focused=false;stopTrack();notes.clear();state="interrupted";}
  },handler).build();
 }
 public void foreground(boolean value){handler.post(()->{foreground=value;if(!value)release();else {waiting=false;state="ready";}});}
 @JavascriptInterface public void enabled(boolean value){handler.post(()->{if(enabled==value)return;enabled=value;if(!value)release();});}
 @JavascriptInterface public String status(){return state;}
 public long playedFrames(){java.util.concurrent.CountDownLatch done=new java.util.concurrent.CountDownLatch(1);handler.post(()->{updateHead();done.countDown();});try{done.await(500,java.util.concurrent.TimeUnit.MILLISECONDS);}catch(InterruptedException e){Thread.currentThread().interrupt();}return playedFrames;}
 @JavascriptInterface public void tone(double frequency,double duration,String type,double gain,double delay){
  if(!Double.isFinite(frequency)||!Double.isFinite(duration)||!Double.isFinite(gain)||!Double.isFinite(delay)||frequency<20||frequency>10000||duration<=0||duration>3||delay<0||delay>2)return;
  handler.post(()->{
   if(!foreground||!enabled||waiting)return;
   handler.removeCallbacks(idle);
   // A permanent loss does not send GAIN later: reacquire on the next burst.
   if(!focused){focused=manager.requestAudioFocus(focus)==AudioManager.AUDIOFOCUS_REQUEST_GRANTED;if(!focused){state="focus unavailable";return;}}
   try{
    if(track==null){track=new AudioTrack.Builder().setAudioAttributes(attributes).setAudioFormat(new AudioFormat.Builder().setSampleRate(RATE).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).setEncoding(AudioFormat.ENCODING_PCM_16BIT).build()).setBufferSizeInBytes(Math.max(BLOCK*4,AudioTrack.getMinBufferSize(RATE,AudioFormat.CHANNEL_OUT_MONO,AudioFormat.ENCODING_PCM_16BIT))).setTransferMode(AudioTrack.MODE_STREAM).build();cursor=0;lastHead=0;if(Build.VERSION.SDK_INT>=31)track.setStartThresholdInFrames(BLOCK);track.play();}
    if(notes.size()>=32)notes.remove(0);
    long start=cursor+(long)(delay*RATE);notes.add(new Note(frequency,Math.max(0,Math.min(.3,gain)),type,start,start+(long)(duration*RATE)));
    state="running";if(!pumping){pumping=true;handler.post(pump);}
   }catch(RuntimeException error){release();state="retry on next sound";}
  });
 }
 @JavascriptInterface public void clearPending(){handler.post(()->{stopTrack();notes.clear();state=enabled?"ready":"muted";});}
 private void pump(){
  pumping=false;if(track==null||!focused||!foreground||!enabled)return;
  if(notes.isEmpty()){
   // Older devices start a stream only once its minimum buffer is filled.
   // Pad after short tones, so clicks can start without waiting for another event.
   if((Build.VERSION.SDK_INT<31||lastHead==0)&&cursor-lastHead<track.getBufferSizeInFrames())try{int missing=(int)(track.getBufferSizeInFrames()-(cursor-lastHead));int written=track.write(new short[missing],0,missing,AudioTrack.WRITE_BLOCKING);if(written<=0)throw new IllegalStateException("Audio padding failed");cursor+=written;updateHead();}catch(RuntimeException error){release();state="retry on next sound";return;}
   drainDeadline=SystemClock.uptimeMillis()+2000;handler.postDelayed(idle,150);return;}
  short[] pcm=new short[BLOCK];
  for(int i=0;i<BLOCK;i++){
   long frame=cursor+i;double sum=0;
   for(Note n:notes){if(frame<n.start||frame>=n.end)continue;double elapsed=(frame-n.start)/(double)RATE,phase=elapsed*n.frequency;double wave;
    switch(n.type){case "buzzer":case "square":wave=Math.sin(phase*2*Math.PI)>=0?1:-1;break;case "triangle":wave=2/Math.PI*Math.asin(Math.sin(phase*2*Math.PI));break;case "sawtooth":wave=2*(phase-Math.floor(phase+.5));break;case "warm":wave=(Math.sin(phase*2*Math.PI)+.18*Math.sin(phase*4*Math.PI)+.06*Math.sin(phase*6*Math.PI))/1.24;break;case "chime":wave=(Math.sin(phase*2*Math.PI)+.28*Math.sin(phase*4*Math.PI)+.12*Math.sin(phase*6*Math.PI)+.04*Math.sin(phase*8*Math.PI))/1.44;break;default:wave=Math.sin(phase*2*Math.PI);}
    double total=(n.end-n.start)/(double)RATE,attack=Math.min(.015,total/2),envelope=elapsed<attack?.0001*Math.pow(Math.max(.001,n.gain)/.0001,elapsed/attack):Math.max(.001,n.gain)*Math.pow(.0001/Math.max(.001,n.gain),(elapsed-attack)/(total-attack));if("buzzer".equals(n.type)&&elapsed>=attack)envelope=n.gain*Math.min(1,(total-elapsed)/.045);sum+=wave*envelope;
   }
   // Soft limiting avoids harsh clipping when several event notes overlap.
   pcm[i]=(short)(Math.tanh(sum*.85)*32767);
  }
  try{
   int written=track.write(pcm,0,pcm.length,AudioTrack.WRITE_BLOCKING);
   if(written<=0)throw new IllegalStateException("Audio write failed: "+written);
   cursor+=written;updateHead();
   notes.removeIf(n->n.end<=cursor);
   pumping=true;handler.post(pump);
  }catch(RuntimeException error){release();state="retry on next sound";}
 }
 private void updateHead(){if(track!=null)try{long head=Integer.toUnsignedLong(track.getPlaybackHeadPosition());playedFrames+=Math.max(0,head-lastHead);lastHead=head;}catch(RuntimeException ignored){}}
 private void finishBurst(){updateHead();if(track!=null&&lastHead<cursor&&SystemClock.uptimeMillis()<drainDeadline){handler.postDelayed(idle,50);return;}release();}
 private void stopTrack(){updateHead();handler.removeCallbacks(pump);handler.removeCallbacks(idle);pumping=false;if(track!=null){try{track.pause();track.flush();track.release();}catch(RuntimeException ignored){}track=null;}cursor=0;}
 private void release(){stopTrack();notes.clear();manager.abandonAudioFocusRequest(focus);focused=false;waiting=false;state=enabled?"ready":"muted";}
 // Foreground means the current audio owner: Activity while visible, service while background.
 public void close(){handler.post(()->{foreground=false;release();thread.quitSafely();});}
}
