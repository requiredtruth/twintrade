# TwinTrade 0.26.0 specification

## Provenance and release lineage
The supplied ZIP contains TwinTrade 0.3.0. It is preserved byte-for-byte in the beta release. The supplied APK is 0.17.0 (versionCode 17); it is preserved byte-for-byte in the supplied-v17 release. Its exact eight web assets were extracted, and its application Java was inspected with JADX. This version reconstructs buildable native Java using the original source plus that analysis, then applies the fixes below. It is not a claim that recompilation reproduces the original APK bytes. This APK uses versionCode 25, versionName 0.25.0, package com.twintrade.app, min API 26 and target API 35.

## Delivered behavior
- Bundled BTC/ETH, distinct BTCDEGEN/ETHDEGEN and broader market registry with runtime discovery. Updated remote caps override bundled caps, and disabled markets cannot be selected for new orders. Native paper caps receive the same registry through the secure local bridge.
- $100 paper account, percentage collateral choices, long/short positions, signed funding, borrowing and both entry/exit fee estimates. Existing positions retain their original cost assumptions. Reset explicitly confirms clearing paper state.
- Android foreground monitoring owns the synchronized paper ledger, all market quotes and up to 600 minute candles per market. Liquidation and cash settlement continue while the WebView is backgrounded. Native and browser duplicate closes do not credit twice.
- Gains v4 mark/index parsing, timestamp checks, reconnect watchdogs, chart snapshots and one-minute history. Cached/history candles do not make an order quote fresh. A quote must be positive, finite, at most five seconds old and not future-dated. Older native ticks do not overwrite newer quotes.
- History requests capture their market before awaiting the network. Concurrent BTC/ETH requests merge only into their originating market. Singleton candles and impossible OHLC values are rejected.
- Public open-trader snapshots and streams, global Polygon/Arbitrum/Base views, same-entry/leverage grouping, yellow/purple entries, liquidation overlays, chart drag/pinch/zoom, sounds, data-rate and freshness indicators. Public P&L and fees are estimates, not authoritative accounting.
- Portrait header actions remain reachable; compact landscape docks the order controls beside the chart.
- Safe-area handling for system bars, display cutouts and keyboard, compact-height layout, settings drawer, native battery settings and full monitor exit.

## Live order execution
Chain: Polygon 137. Diamond 0x209A9A01980377916851af2cA075C2b170452018. Native USDC 0x3c499c542cEF5E3811e1192ce70d8cC03d5c3359, six decimals, collateral index 3. HTTPS/WSS nodes are configurable and checked against Polygon. Contract addresses and market names are validated before execution; simulation remains the final contract preflight.

Android Keystore encrypts a user-supplied wallet key. The browser build cannot persist a key or sign without this bridge. Enabling live mode is explicit. Every live open and close requires confirmation. Open review shows market, side, collateral, leverage, notional and maximum slippage before approval/signing. USDC approval is connected to the wallet signer, with an exact allowance. Live expected prices use fresh index quotes rather than chart mark prices. No wallet is generated, funded or traded during development.

Pending requests are persisted and shown. Open/close submission is serialized; unresolved pending/uncertain orders block another order for the wallet. Receipt waits have a 60-second ceiling: timeout means uncertain, not success. Receipt/order reconciliation continues every 12 seconds and when returning to the app. Approval-only submissions reconcile separately. Successful replacement receipts are accepted. Wallet/node/mode changes are blocked while an order is actively submitting. No automatic retry sends another trading transaction.

## Validation
Six JavaScript regression suites cover accounting, SDK liquidation calculations, protocol constants, actual application handlers, duplicate settlement, signer-bound approval, rejected review, pending-order exclusion, market-switch history races, dynamic leverage changes, disabled markets, quote freshness and malformed candles/costs. Two Java ledger suites cover native allocation, liquidation, settlement, DEGEN markets, duplicate settlement, caps and timestamp/candle/cost validation. APK is compiled from the delivered Java/assets, aligned and signature verified. CI runs the standalone HTML in Chromium at 393×852, 852×393, 360×640 and 740×360, including repeated rotations, paper order rendering and settings controls, before release publication.

## Operational limits
No funded end-to-end open/close transaction and no physical Android installation were performed. Browser rendering is verified by CI; native lifecycle/insets still need device testing. Service uptime depends on Android power policy and user notification/background permissions. Public feeds, history APIs, oracle availability and RPC services can fail; stale quotes pause submission. A receipt does not establish oracle execution. Ambiguous order resolution remains visible for chain inspection. The current journal does not retain a signed prebroadcast transaction; a provider failure before returning a hash still requires checking the wallet on-chain before attempting another order. External market/contract changes may require another release. No promise of uninterrupted exchange service is made.

## Signing and artifacts
The original APK retains its original certificate. The rebuilt release has a new certificate and cannot update that installation directly. Back up wallet recovery material before uninstalling. Public release files are TwinTrade.apk, TwinTrade.html, TwinTrade-source.zip, spec.md and SHA256SUMS. Signing private keys and wallet keys are excluded.

## 0.20.0 stable chart and account views
- Public trade reloads publish atomically after all chain responses. Malformed or failed responses retain the previous chain. One missing snapshot retains an entry; two complete valid absences reconcile it. Confirmed close events remove immediately. Opens, closes and updates received during reload take precedence over its older response.
- Public contract events and backend snapshots share chain/address/index identity. Last known liquidation is retained during partial updates. No 400/600 trade tracking caps or price-dependent nearest-60 selection; tracked lines remain until reconciled closure or user filtering. Off-chart prices remain tracked; normal price-focused scaling is retained.
- Reset chart restores 75 candles, latest time, vertical center and clears selected-trader focus. It does not reset accounts.
- Optional bold notional-weighted average entry and liquidation lines by side and nearest leverage band (50, 75, 100, 150, 200, 500, 1000). Positions below 50x are excluded. Missing liquidations do not enter the liquidation denominator; labels show coverage. These span all tracked trades in the current market, independent of the selected trader.
- Healthy status is steady. Price delay/unavailability is shown only after five seconds, recovers on fresh quotes, and retains chart/positions. Historical OHLC snapshots never renew executable quote timestamps. Existing stale-order protection remains active.
- Menu Portfolio and Past trades cover all markets in the active paper/live mode. Portfolio shows available balance, collateral, notional, estimated net/equity, and individual positions. Paper closures persist through the native ledger. Locally observed live closures are saved per wallet with unavailable settlement until confirmed data is available. The live history page also imports matching-address Polygon closures from public 24h history when available; it does not claim complete lifetime exchange history or invent realized P&L.
- JavaScript/native regression tests cover snapshot races, malformed and partial snapshots, immediate close events, partial leverage updates, liquidation retention, weighted averages, desync threshold/recovery, chart reset, and all-market account views. Browser CI verifies actual rendering and repeated mobile rotations before publishing. No funded mainnet order or physical Android device test performed.
- APK uses the same signing certificate as 0.19.0 for in-place updates. Private signing key remains outside the repository and source ZIP.


## 0.21.0 candle continuity and fee/P&L corrections

- Candles have one bucket per minute. Internal missing minutes carry the previous known close as explicitly marked amber flat placeholders; no invented extremes, interpolated price moves, timestamps in the future, or refreshed quote age. Gaps are not silently collapsed in time. The status states how many placeholders await history.
- Reconcile selected market history every minute and when returning to the app, including the native app. Completed authoritative history replaces partial recorded bars and missing-minute placeholders; remaining placeholders are recalculated. A 600-minute retention cap bounds long outages. Native background history also retries every minute. Polygon history is preferred; Arbitrum fallback is explicitly named in chart status.
- Own position chart labels now show NET with the same paper/live value calculation as cards. The average entry label sums only positions in the chart's market; the portfolio still sums every market. Public traders' P&L remains a gross estimate because their costs are unknown.
- Fees are charged on notional. BTC: $100 collateral x 200 = $20,000 notional, standard .035% opening = $7 and .035% closing = $7, total $14 before spread, holding, discounts and closing fee decay. Open fee and estimated closing fee are separate labels.
- New paper positions use available Polygon contract fee/spread and recent Polygon per-side hourly rates. Funding short rates are independent of long rates. Existing positions keep original cost assumptions; paper holding rates are frozen at entry and labeled accordingly. Unavailable Polygon rates use explicit settings assumptions; Arbitrum holding rates are never represented as Polygon rates. DEGEN base opening/closing fallback is .02%.
- Paper is an estimate, without user volume/staking discounts, minimum-fee modeling, dynamic impact or the temporary closing fee decay. The quote states this. It is not a promise of a live settlement amount.
- Live cards include realized trading fees, signed borrowing/funding, and estimated base closing fee. Base closing fee uses effective counter-trade rate and the trader's on-chain fee discount. Live net includes realized P&L from the fee ledger; price impact, minimum fees, closing decay and gas mean settlement can differ. Unavailable cost reads leave net unavailable rather than inventing an amount.
- Negative combined holding costs are labeled Hold gain in green; positive costs are Hold loss in red. Funding component also says earned/paid. Closed paper trade cost details stop accruing at the recorded closure time.
- VersionCode 21, versionName 0.21.0; same certificate as v0.19.0/v0.20.0 for update compatibility. No private key is distributed.

## 0.22.0 quiet alerts and current stats
- Removed the repeating near-liquidation sound and feed notification. Actual liquidation, closure and entry/LIQ crossing events continue working.
- Gains price desync/unavailable banner appears at 30 seconds and clears on recovery. Fresh-order quote checks remain five seconds; the warning threshold does not permit stale orders.
- Stats button opens a current-market popup, updated once per second while visible: mark/index, quote age, data rate, feed state, per-chain tracked counts, available balance, pending orders, own estimated net P&L, current market fees and order estimate. Long/short tables show collateral, notional, weighted entry/leverage/LIQ and LIQ coverage, with separate high-leverage bands and own positions. Missing liquidation prices are excluded from their average. Tables scroll horizontally inside the popup on phones.
- Leverage-band chart aggregates are cached until trade/liquidation data or market changes, eliminating unchanged aggregation on every redraw.
- Fixed own live liquidation lines to use their contract-derived price rather than paper-cost math. Public gross P&L is labeled GROSS instead of NET.
- Old background price-socket callbacks no longer overwrite the replacement connection status.
- VersionCode 22, versionName 0.22.0, update certificate identical to v0.21.0. Source/native regression suites and APK signature checks pass; CI validates popup updates, 30-second boundary, order controls, fee colors and repeated mobile rotations before publishing. No physical device or funded live trade was tested.

## 0.24.0 price-socket recovery
- Fixed the Android path that has a Feed bridge but no active background monitor: foreground price recovery now starts even when Keep Alive is off, including after Exit app and reopen. With an active but stalled monitor, a foreground recovery socket starts after eight seconds without fresh selected-market quotes. It closes when the Android page becomes hidden and resumes recovery on return.
- Recovery frames enter the synchronized native ledger through a bounded bridge; charts, paper orders, settlement and liquidation share the same real quote owner. Native and foreground transports use the same PriceFeed parser. Invalid individual pairs no longer discard the remaining valid pairs in a frame. Timestamp freshness, future rejection, actual index/mark separation and order preflight remain enforced. Heartbeats cannot fabricate fresh prices or index quotes.
- Keep Alive reflects its saved preference instead of being incorrectly overwritten with whether the monitor is running. No automatic wallet trading or background-preference change.
- Stats includes native monitor status, foreground socket status, timestamp errors and index-quote availability. Reconnect price feed explicitly replaces the foreground socket and reconnects the native monitor when it is running.
- Added actual native-frame/ledger tests and Android-bridge browser coverage with background monitoring off. CI also opens the live Gains v4 WebSocket read-only and requires a fresh BTC price before publishing; no funded transaction is performed.
- VersionCode 23 / 0.24.0, same update certificate as 0.22.0. Physical device behavior still requires user confirmation.

## 0.24.0 average liquidation overlays
- All-leverage long/short average entry and liquidation lines, plus existing high-leverage bands, use the same cached statistics as the popup and refresh on public trade changes.
- Known liquidation averages remain separate. Missing prices get an explicitly labeled reference estimate per position: entry × (1 ± 0.9 / leverage), weighted by collateral × leverage alongside known values. This uses a 90% collateral-loss assumption before unknown fees, spread, realized P&L and current dynamic liquidation thresholds; it is not an authoritative Gains liquidation quote.
- EST labels and known/estimated coverage appear in stats and on chart lines. Known prices take precedence automatically when backfilled. Empty sides produce no line; price-focused chart scaling is preserved.

## 0.25.0 stable status layout and request/render fixes
- Removed the green loading/Ready progress bar. Sync text uses a fixed two-line strip above the borrowing text; showing, replacing or clearing it cannot resize the chart in portrait or landscape. Completed messages expire after 3.5 seconds, in-progress text after 8 seconds. Routine Ready callbacks do not erase newer sync text.
- History failures keep one retry timer per market; new requests clear older retries and retries stop after switching away or hiding the app.
- Same-market holding/fee refreshes and chart snapshots cannot overlap. Holding-rate updates retain the verified contract spread and fee metadata. Fetch aborts remain active through JSON parsing and timers are cleared on all exit paths.
- Backend changes during a snapshot queue a follow-up reload; an old long-running snapshot cannot be replaced by another writer. Confirmed changes continue to overlay snapshots through the existing revision/tombstone system.
- Unchanged positions/trader markup reuses existing DOM, preserving controls and reducing layout work. Chart slices no longer repeat a sort/dedup already performed on the full series. Missing native history labels retain the existing text.
- Regression coverage includes timer replacement, market-switch retry cleanup, spread preservation, request deduplication, pending reloads and native missing-history behavior. Chromium checks geometry with status messages visible/hidden across five viewport transitions, replacement timer expiration, paper trading, stats, fees, and Android foreground bridge recovery.
- APK built and signature verified against the v0.24.0 certificate. No physical Android device or funded order tested in this change. Local read-only live price probe is blocked by DNS in this execution environment; GitHub CI runs the same probe before publishing.

## 0.26.0 chart controls and app continuity

- Chart/card side labels use L/S, without OTHER or GROSS. Leverage and collateral cash labels truncate decimals; prices, fees and P&L retain precision. Arithmetic and settlement retain their original precision.
- Zoom submenu contains reset, zoom in/out, min (1w), max (10m), 15m/1h/4h/1d/1w ranges, and Auto/1m/5m/15m/1h/4h/1d candle aggregation. Pinch and wheel use the expanded bounds. History uses bounded 300-minute pages, three concurrent requests, up to 10,080 retained minute candles; larger candle intervals aggregate actual OHLC. Missing minutes remain amber placeholders until real history arrives.
- Regular BTC displays BTC and BTCDEGEN public entry and LIQ overlays and combines their public averages/stats. BTCDEGEN entries have a D marker and cards identify BTCDEGEN. This affects visualization only; order pair selection and prices remain independent.
- Each displayed public position has its own known or estimated liquidation boundary, including positions with clustered entry lines. Missing LIQ uses entry ± entry × 0.9 / leverage, before unknown fees/spread/dynamic thresholds, labeled EST. Exact LIQs replace estimates as available. Boundaries outside the visible price range remain offscreen.
- Returning from another app keeps the WebView and chart alive; native resume never navigates or reloads the page. Short returns skip full public/history reloads when recently refreshed; stale returns reconcile without clearing trades or resetting zoom. The launcher reuses the existing activity. Background checkpoints preserve market, zoom, pan, candle interval, overlay toggles, selected trade, cached entries/LIQs and selected-market candles for recreation. Cache values never authorize an order; existing fresh quote checks still apply.
- Validation: source/native regressions, deterministic known/estimated BTCDEGEN overlays, range limits, real hour/day OHLC aggregation, resume refresh gates, checkpoint restoration, mobile browser menu/rotation/recreation tests and signed APK verification. Physical Android task-switch testing remains required for device-specific lifecycle behavior. No funded trade performed.

## Version 0.27.0 — Startup recovery

Validate saved chart sessions and cached public-trade rows before startup; invalid rows are discarded while valid trades, zoom and scroll settings remain. Android resume callbacks wait for the bundled page to finish loading. Background monitor starts run on the Activity main thread only while resumed; platform service-start/foreground-registration restrictions leave the foreground price path available. Wallet storage is untouched.

Regression coverage includes malformed cached sessions, valid-state preservation, app handlers, native ledger/feed tests, mobile browser tests and an Android 15 emulator gate for cold launch, app switching and process recreation. Emulator logs and screenshot are uploaded by CI before release publication.

## Version 0.28.0 — Candle gap recovery

Missing retained one-minute buckets are backfilled by their actual timestamps, including gaps older than the normal five-hour refresh. A sweep repairs at most three pages of up to 298 missing minutes each, trying Polygon then Arbitrum for unresolved buckets. Pages rotate to avoid starvation and successful pages survive other page failures. Historical OHLC replaces placeholders; unavailable minutes remain visibly marked and are never relabeled as genuine data.

Incomplete successful responses schedule recovery as well as transport errors. One timer per market retries at 30 seconds while making progress, backing off to five minutes without progress. Regular polling respects this timer; larger queued zoom requests retain their requested range. Native history uses its existing fixed-delay minute job without spawning extra retry chains. Retained history remains bounded to one week in the browser and 600 bars in the native ledger. Upstream data availability still determines whether all gaps can be resolved.

Regression tests reproduce 73 missing minutes older than the normal refresh, incomplete Polygon history repaired by Arbitrum, partial page failures, retry deduplication/backoff and week-long outage paging.
