package com.twintrade.app;
import android.app.*;import android.os.*;import android.webkit.*;import android.view.*;import android.content.*;import android.security.keystore.*;import android.util.Base64;import java.security.*;import javax.crypto.*;import javax.crypto.spec.GCMParameterSpec;import java.io.*;
public class MainActivity extends Activity {
 public static volatile boolean visible=false;
 private NativeAudio audio;private WebView web;private boolean resumed=false,pageReady=false;
 private static final int SAVE_ERROR_REPORT=73;
 private String errorReport;
 private final BroadcastReceiver timeZoneChanges=new BroadcastReceiver(){
  @Override public void onReceive(Context context,Intent intent){
   if(web!=null&&pageReady)web.evaluateJavascript("if(typeof refreshDeviceTimeZone==='function')refreshDeviceTimeZone();",null);
  }
 };
 @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
  super.onActivityResult(requestCode,resultCode,data);
  if(requestCode!=SAVE_ERROR_REPORT)return;
  String report=errorReport;
  errorReport=null;
  if(resultCode!=RESULT_OK||data==null||data.getData()==null||report==null)return;
  try(OutputStream out=getContentResolver().openOutputStream(data.getData(),"wt")){
   if(out==null)throw new IOException("No writable file");
   out.write(report.getBytes(java.nio.charset.StandardCharsets.UTF_8));
   android.widget.Toast.makeText(this,"Error report saved",android.widget.Toast.LENGTH_SHORT).show();
  }catch(IOException|SecurityException e){
   android.widget.Toast.makeText(this,"Could not save error report",android.widget.Toast.LENGTH_LONG).show();
  }
 }
 @Override protected void onSaveInstanceState(Bundle state){
  super.onSaveInstanceState(state);
  if(errorReport!=null)state.putString("errorReport",errorReport);
 }
 @Override public void onCreate(Bundle state){super.onCreate(state);if(state!=null)errorReport=state.getString("errorReport");MarketStore.init(this);audio=new NativeAudio(this);getWindow().clearFlags(WindowManager.LayoutParams.FLAG_SECURE);getWindow().setStatusBarColor(0xff171e27);getWindow().setNavigationBarColor(0xff151c25);// Insets belong on the native parent: WebView padding does not reliably shrink its HTML viewport.
 if (Build.VERSION.SDK_INT >= 30) getWindow().setDecorFitsSystemWindows(false);
 else getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
 android.widget.FrameLayout safeArea = new android.widget.FrameLayout(this);
 safeArea.setBackgroundColor(0xff151c25);
 web=new WebView(this);
 safeArea.addView(web,new android.widget.FrameLayout.LayoutParams(android.widget.FrameLayout.LayoutParams.MATCH_PARENT,android.widget.FrameLayout.LayoutParams.MATCH_PARENT));
 setContentView(safeArea);
 safeArea.setOnApplyWindowInsetsListener((v,insets)->{
  if(Build.VERSION.SDK_INT>=30){
   android.graphics.Insets bars=insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
   android.graphics.Insets keyboard=insets.getInsets(WindowInsets.Type.ime());
   v.setPadding(bars.left,bars.top,bars.right,Math.max(bars.bottom,keyboard.bottom));
   return WindowInsets.CONSUMED;
  }
  v.setPadding(insets.getSystemWindowInsetLeft(),insets.getSystemWindowInsetTop(),insets.getSystemWindowInsetRight(),insets.getSystemWindowInsetBottom());
  return insets.consumeSystemWindowInsets();
 });
 safeArea.requestApplyInsets();WebSettings s=web.getSettings();s.setJavaScriptEnabled(true);s.setMediaPlaybackRequiresUserGesture(false);s.setDomStorageEnabled(true);s.setAllowFileAccess(false);s.setAllowContentAccess(false);s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);web.addJavascriptInterface(audio,"NativeAudio");web.addJavascriptInterface(new Vault(),"Vault");web.addJavascriptInterface(new Feed(),"Feed");web.setWebChromeClient(new WebChromeClient(){@Override public boolean onConsoleMessage(ConsoleMessage msg){if(msg.message().startsWith("Audio engine: "))android.util.Log.i("TwinTrade",msg.message());if(msg.messageLevel()==ConsoleMessage.MessageLevel.ERROR)android.util.Log.w("TwinTrade","WebView script error at line "+msg.lineNumber()+": "+msg.message());return true;}@Override public boolean onJsConfirm(WebView v,String url,String message,JsResult result){new AlertDialog.Builder(MainActivity.this).setMessage(message).setPositiveButton("Confirm",(d,w)->result.confirm()).setNegativeButton("Cancel",(d,w)->result.cancel()).setOnCancelListener(d->result.cancel()).show();return true;}});web.setWebViewClient(new WebViewClient(){@Override public void onPageFinished(WebView view,String url){if(view==web&&"https://app.twintrade.local/index.html".equals(url)){pageReady=true;web.evaluateJavascript("!!(document.getElementById('long') && typeof document.getElementById('long').onclick==='function')",ready->android.util.Log.i("TwinTrade","Trading page initialized: "+ready));if(resumed)resumePage();}}@Override public boolean shouldOverrideUrlLoading(WebView view,WebResourceRequest req){return true;}@Override public WebResourceResponse shouldInterceptRequest(WebView view,WebResourceRequest req){if(!"app.twintrade.local".equals(req.getUrl().getHost()))return null;try{String path=req.getUrl().getPath();if(path==null||path.equals("/"))path="/index.html";if(path.contains(".."))throw new IOException();String mime=path.endsWith(".js")?"application/javascript":path.endsWith(".css")?"text/css":"text/html";WebResourceResponse response=new WebResourceResponse(mime,"UTF-8",getAssets().open(path.substring(1)));java.util.Map<String,String> headers=new java.util.HashMap<>();headers.put("Content-Security-Policy","default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; connect-src https: wss:; img-src 'self' data:; object-src 'none'; frame-src 'none'; base-uri 'none'");response.setResponseHeaders(headers);return response;}catch(Exception e){return new WebResourceResponse("text/plain","UTF-8",404,"Not Found",null,new ByteArrayInputStream(new byte[0]));}}});web.loadUrl("https://app.twintrade.local/index.html");
 IntentFilter zones=new IntentFilter(Intent.ACTION_TIMEZONE_CHANGED);
 if(Build.VERSION.SDK_INT>=33)registerReceiver(timeZoneChanges,zones,Context.RECEIVER_NOT_EXPORTED);
 else registerReceiver(timeZoneChanges,zones);
 // Start monitoring from onResume, once the Activity is foreground eligible.
 if(Build.VERSION.SDK_INT>=33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS")!=android.content.pm.PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"},8);
}
 // Keep the existing WebView when returning from another app. Never navigate/reload on resume.
 private void resumePage(){if(web!=null&&pageReady){web.evaluateJavascript("if(typeof onAppResume==='function')onAppResume();",null);new Handler(getMainLooper()).postDelayed(()->{if(resumed&&audio!=null)android.util.Log.i("TwinTrade","Audio engine: "+audio.status());},500);}}
 private void startMonitor(String action){runOnUiThread(()->{if(!resumed||isFinishing()||isDestroyed())return;try{Intent request=new Intent(this,PriceMonitorService.class);if(action!=null)request.setAction(action);startForegroundService(request);}catch(RuntimeException e){MarketStore.running=false;MarketStore.status="Background monitor unavailable · foreground prices active";android.util.Log.w("TwinTrade","Monitor start rejected",e);}});}
 @Override protected void onResume(){super.onResume();resumed=true;visible=true;PriceMonitorService.visibilityChanged();audio.foreground(true);if(web!=null){web.onResume();resumePage();}if(getSharedPreferences("market",0).getBoolean("keepAlive",true))startMonitor(null);}
 @Override protected void onPause(){resumed=false;visible=false;audio.foreground(false);PriceMonitorService.visibilityChanged();if(web!=null){if(pageReady)web.evaluateJavascript("if(typeof checkpointSession==='function')checkpointSession();",null);web.onPause();}super.onPause();}
 @Override protected void onNewIntent(Intent intent){super.onNewIntent(intent);setIntent(intent);}
 @Override protected void onDestroy(){unregisterReceiver(timeZoneChanges);if(audio!=null)audio.close();if(web!=null){web.removeJavascriptInterface("NativeAudio");web.removeJavascriptInterface("Vault");web.removeJavascriptInterface("Feed");web.destroy();web=null;}super.onDestroy();}
 @Override public void onBackPressed(){web.evaluateJavascript("if(document.getElementById('ratiosDialog').open)document.getElementById('ratiosDialog').close();else if(document.getElementById('chartInfoDialog').open)document.getElementById('chartInfoDialog').close();else if(document.getElementById('config').open)document.getElementById('config').close();else {document.getElementById('drawer').hidden=true;document.getElementById('shade').hidden=true;}",null);}

 public class Feed {
  @JavascriptInterface public String timeZone(){return java.util.TimeZone.getDefault().getID();}
  @JavascriptInterface public void saveErrorReport(String report){
   if(report==null||report.length()>150000)return;
   runOnUiThread(()->{
    if(errorReport!=null)return;
    errorReport=report;
    Intent save=new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE)
      .setType("text/plain").putExtra(Intent.EXTRA_TITLE,"TwinTrade-errors.txt");
    try{startActivityForResult(save,SAVE_ERROR_REPORT);}
    catch(ActivityNotFoundException e){
     errorReport=null;
     android.widget.Toast.makeText(MainActivity.this,"No file picker available",android.widget.Toast.LENGTH_LONG).show();
    }
   });
  }
  @JavascriptInterface public void audioState(String raw){if(raw==null||raw.length()>200000)return;try{org.json.JSONObject state=new org.json.JSONObject(raw);int selected=state.getInt("pair");if(selected<0||selected>1000)return;getSharedPreferences("market",0).edit().putString("audioState",raw).apply();PriceMonitorService.visibilityChanged();}catch(Exception ignored){}}
  @JavascriptInterface public void updateCaps(String raw){MarketStore.updateCaps(raw);}
  @JavascriptInterface public void exitApp(){
   getSharedPreferences("market",0).edit().putBoolean("keepAlive",false).apply();
   stopService(new Intent(MainActivity.this,PriceMonitorService.class));
   runOnUiThread(()->{finishAndRemoveTask();new Handler().postDelayed(()->android.os.Process.killProcess(android.os.Process.myPid()),500);});
  }
  @JavascriptInterface public int acceptPriceFrame(String raw){return PriceFeed.ingest(raw,System.currentTimeMillis());}
  @JavascriptInterface public void reconnect(){startMonitor("RECONNECT");}
  @JavascriptInterface public String backgroundEvent(){return getSharedPreferences("market",0).getString("backgroundTradeEvent","{}");}
  @JavascriptInterface public String snapshot(){return MarketStore.snapshot();}
  @JavascriptInterface public String snapshotFor(int pair,long revision){return MarketStore.snapshotFor(pair,revision);}
  @JavascriptInterface public void seed(String raw){MarketStore.seed(raw);}
  @JavascriptInterface public String paper(){return MarketStore.book();}
  @JavascriptInterface public String openDollars(int pair,boolean isLong,double amount,double lev,String cost){return MarketStore.openDollars(pair,isLong,amount,lev,cost);}
  @JavascriptInterface public String open(int pair,boolean isLong,double percent,double lev,String cost){return MarketStore.open(pair,isLong,percent,lev,cost);}
  @JavascriptInterface public String setExits(String id,String json){return MarketStore.setExits(id,json);}
  @JavascriptInterface public String close(String id){return MarketStore.close(id);}
  @JavascriptInterface public int recoverHoldingRates(int pair,double borrowLong,double borrowShort,double fundLong,double fundShort){return MarketStore.recoverHoldingRates(pair,borrowLong,borrowShort,fundLong,fundShort,System.currentTimeMillis());}
  @JavascriptInterface public void reset(){MarketStore.reset();}
  @JavascriptInterface public void keepAlive(boolean enabled){getSharedPreferences("market",0).edit().putBoolean("keepAlive",enabled).apply();if(enabled)startMonitor(null);else stopService(new Intent(MainActivity.this,PriceMonitorService.class));}
  @JavascriptInterface public void batterySettings(){runOnUiThread(()->{try{startActivity(new Intent(android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));}catch(Exception ignored){}});}
 }
 public class Vault {
 private SecretKey key()throws Exception{KeyStore ks=KeyStore.getInstance("AndroidKeyStore");ks.load(null);if(!ks.containsAlias("TwinTradeWallet")){KeyGenerator g=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");g.init(new KeyGenParameterSpec.Builder("TwinTradeWallet",KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT).setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).setRandomizedEncryptionRequired(true).build());g.generateKey();}return (SecretKey)ks.getKey("TwinTradeWallet",null);}
 @JavascriptInterface public synchronized String save(String value){if(!value.matches("0x[0-9a-fA-F]{64}"))return "Invalid key";try{Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.ENCRYPT_MODE,key());String payload=Base64.encodeToString(c.getIV(),Base64.NO_WRAP)+":"+Base64.encodeToString(c.doFinal(value.getBytes("UTF-8")),Base64.NO_WRAP);return getSharedPreferences("vault",MODE_PRIVATE).edit().putString("wallet",payload).commit()?"OK":"Storage failed";}catch(Exception e){return "Key encryption failed";}}
 @JavascriptInterface public synchronized String load(){try{String s=getSharedPreferences("vault",MODE_PRIVATE).getString("wallet","");if(s.isEmpty())return "";String[] a=s.split(":");Cipher c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.DECRYPT_MODE,key(),new GCMParameterSpec(128,Base64.decode(a[0],Base64.NO_WRAP)));return new String(c.doFinal(Base64.decode(a[1],Base64.NO_WRAP)),"UTF-8");}catch(Exception e){return "";}}
 @JavascriptInterface public synchronized void forget(){getSharedPreferences("vault",MODE_PRIVATE).edit().clear().commit();try{KeyStore ks=KeyStore.getInstance("AndroidKeyStore");ks.load(null);ks.deleteEntry("TwinTradeWallet");}catch(Exception ignored){}}
 }
}
