package com.twintrade.app;
import android.app.*;import android.content.*;import android.content.pm.ServiceInfo;import android.os.*;import org.json.*;import java.net.*;import java.io.*;import java.util.concurrent.*;
public class PriceMonitorService extends Service {
 private static volatile PriceMonitorService instance;private final Object audioLock=new Object();private Notification.Builder notificationBuilder;private long notificationAt=0;private int holdingCursor=0;
 private NativeAudio backgroundAudio;private TickSound sonifier;private final EventSoundPalette.BurstGate tradeSoundGate=new EventSoundPalette.BurstGate();private volatile boolean ownsAudio=false;private String lastPaperCloseId="";private int soundPair=-1;private long soundMinute=0,lastPnlCrossAt=Long.MIN_VALUE;private double soundOpen=0,soundLast=0;
 public static void visibilityChanged(){PriceMonitorService s=instance;if(s!=null)s.updateAudioOwnership();}
 private JSONObject audioState(){try{return new JSONObject(getSharedPreferences("market",0).getString("audioState","{}"));}catch(Exception e){return new JSONObject();}}
 private double soundLevel(JSONObject state){double level=state.optDouble("level",1);return Double.isFinite(level)&&level>0&&level<=1?level:1;}
 private void updateAudioOwnership(){synchronized(audioLock){if(backgroundAudio==null)return;JSONObject state=audioState();boolean active=!MainActivity.visible&&!stopped&&getSharedPreferences("market",0).getBoolean("keepAlive",true),enabled=state.optBoolean("ticks",true)||state.optBoolean("events",true);if(active!=ownsAudio){ownsAudio=active;settlementAudioHandler.removeCallbacksAndMessages(null);settlementSoundUntil=0;backgroundAudio.foreground(active);if(sonifier!=null)sonifier.reset();soundPair=-1;}backgroundAudio.enabled(enabled);}}
 private int acceptBackgroundFrame(String raw){synchronized(audioLock){if(stopped)return 0;
  JSONObject state=audioState();int selected=state.optInt("pair",0);double prev=MarketStore.priceOf(selected);int accepted=PriceFeed.ingest(raw,System.currentTimeMillis());if(accepted<=0)return accepted;
  updateAudioOwnership();double next=MarketStore.priceOf(selected);String closeId=MarketStore.latestPaperCloseId();
  java.util.ArrayDeque<JSONObject> closes=MarketStore.paperClosesSince(lastPaperCloseId);lastPaperCloseId=closeId;
  if(!ownsAudio)return accepted;
  double[] context=MarketStore.paperSoundState(selected);
  if("live".equals(state.optString("mode"))){double total=0,exposure=0;int count=0;JSONArray ps=state.optJSONArray("positions");if(ps!=null)for(int i=0;i<ps.length();i++)try{JSONObject p=ps.getJSONObject(i);int pair=p.getInt("pair");if(pair!=selected&&!(selected==0&&pair==300))continue;double px=MarketStore.priceOf(pair),n=p.getDouble("amount")*p.getDouble("lev"),entry=p.getDouble("entry"),d=p.getBoolean("long")?1:-1;if(px>0&&entry>0){exposure+=d*n/entry;if(!p.isNull("adjustment")){total+=n*d*(px/entry-1)+p.getDouble("adjustment");count++;}}}catch(Exception ignored){}context=new double[]{count>0?total/count:Double.NaN,exposure};}
  long now=SystemClock.elapsedRealtime(),minute=System.currentTimeMillis()/60000;double level=soundLevel(state);int pnlCross=!closes.isEmpty()||now<settlementSoundUntil?0:entryCrossing(state,selected,prev,next,now);
  if(soundPair!=selected){soundPair=selected;soundMinute=minute;soundOpen=soundLast=next;lastPnlCrossAt=Long.MIN_VALUE;sonifier.reset();pnlCross=0;}
  if(pnlCross!=0&&state.optBoolean("events",true)){sonifier.suppressUntil(now+520);backgroundAudio.clearPending();EventSoundPalette.play((f,d,t,g,w)->backgroundAudio.tone(f,d,t,g*level,w),pnlCross>0?"profit":"loss",true,state.optString("profile","gentle"));}
  if(now>=settlementSoundUntil&&state.optBoolean("ticks",true)){
   boolean minuteChanged=minute!=soundMinute,candle=pnlCross==0&&minuteChanged&&soundOpen>0&&soundLast>0;
   if(candle)sonifier.suppressUntil(now+140);
   sonifier.tick(selected,prev,next,now,context[0],context[1],level);
   if(candle){backgroundAudio.clearPending();CandleSound.play(backgroundAudio::tone,soundLast-soundOpen,context[1],level);}
   if(minuteChanged){soundMinute=minute;soundOpen=next;}
  }
  soundLast=next;
  if(state.optBoolean("events",true))for(JSONObject closed:closes)playSettlement("Liquidated".equals(closed.optString("status"))?"liq":"close",closed.optBoolean("long"),closed.optDouble("net"),now,level);
  if(now-notificationAt>5000&&notificationBuilder!=null){notificationAt=now;notificationBuilder.setContentText(state.optString("symbol","Market")+" · "+String.format(java.util.Locale.US,"$%.2f",next)+(state.optBoolean("ticks",true)||state.optBoolean("events",true)?" · prices, candles and sounds active":" · prices and candles active; sounds muted"));((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(42,notificationBuilder.build());}
  return accepted;
 }}

 private final Handler settlementAudioHandler=new Handler(Looper.getMainLooper());
 private long settlementSoundUntil;
 private void playSettlement(String action,boolean longSide,double net,long now,double level){
  long start=Math.max(now,settlementSoundUntil);
  long duration="liq".equals(action)?3000:net>0?590:net<0?480:230;
  settlementSoundUntil=start+duration+65;
  sonifier.suppressUntil(settlementSoundUntil);
  Runnable play=()->{synchronized(audioLock){
   if(!ownsAudio||stopped||backgroundAudio==null||!audioState().optBoolean("events",true))return;
   backgroundAudio.clearPending();
   EventSoundPalette.settlement((f,d,t,g,w)->backgroundAudio.tone(f,d,t,g*level,w),action,longSide,net);
  }};
  if(start==now)play.run();else settlementAudioHandler.postDelayed(play,start-now);
 }
 private int entryCrossing(JSONObject state,int selected,double previous,double next,long now){
  if(lastPnlCrossAt!=Long.MIN_VALUE&&now-lastPnlCrossAt<2000)return 0;
  try{JSONArray positions;if("live".equals(state.optString("mode")))positions=state.optJSONArray("positions");else positions=new JSONObject(MarketStore.book()).optJSONArray("positions");if(positions==null)return 0;
   for(int i=0;i<positions.length();i++){JSONObject p=positions.optJSONObject(i);if(p==null)continue;int pair=p.optInt("pair",-1);if(pair!=selected&&!(selected==0&&pair==300))continue;int result=EntryCrossing.outcome(p.optDouble("entry",Double.NaN),p.optBoolean("long"),previous,next);if(result!=0){lastPnlCrossAt=now;return result;}}
  }catch(Exception ignored){}return 0;
 }

 private void backgroundTrade(JSONObject event){synchronized(audioLock){if(stopped||MainActivity.visible||backgroundAudio==null)return;JSONObject state=audioState();int selected=state.optInt("pair",0),pair=event.optInt("pair",-1);String symbol=event.optString("symbol"),selectedSymbol=state.optString("symbol");boolean matches=pair==selected||selected==0&&pair==300||!symbol.isEmpty()&&(symbol.equals(selectedSymbol)||selected==0&&symbol.equals("BTCDEGEN/USD"));String action=event.optString("action");boolean side=event.optBoolean("long");
  String owner=state.optString("owner");boolean own="live".equals(state.optString("mode"))&&!owner.isEmpty()&&owner.equalsIgnoreCase(event.optString("user"));
  if(own&&!"open".equals(action)){double net=event.optDouble("settledNet",Double.NaN);if(state.optBoolean("events",true)&&("liq".equals(action)||Double.isFinite(net))){updateAudioOwnership();if(ownsAudio)playSettlement(action,side,net,SystemClock.elapsedRealtime(),soundLevel(state));}return;}
  if(!matches)return;try{event.put("pair",pair<0?selected:pair).put("text",(symbol.isEmpty()?selectedSymbol:symbol)+" · "+event.optString("net")+" · "+action.toUpperCase(java.util.Locale.US)+" "+(side?"L":"S"));getSharedPreferences("market",0).edit().putString("backgroundTradeEvent",event.toString()).apply();}catch(Exception ignored){}if(!state.optBoolean("events",true))return;updateAudioOwnership();long now=SystemClock.elapsedRealtime();if(now<settlementSoundUntil)return;int decision=tradeSoundGate.accept(action,now);if(decision<0)return;sonifier.suppressUntil(now+520);backgroundAudio.clearPending();double level=soundLevel(state);EventSoundPalette.play((f,d,t,g,w)->backgroundAudio.tone(f,d,t,g*level,w),action,side,state.optString("profile","gentle"));}}

 private BackgroundTrades trades;private BackgroundPriceFeed feed;private final ScheduledExecutorService jobs=Executors.newScheduledThreadPool(3);private PowerManager.WakeLock wake;private volatile boolean stopped=false;private volatile boolean historyBusy=false;
 public void onCreate(){super.onCreate();MarketStore.init(this);instance=this;backgroundAudio=new NativeAudio(this);sonifier=new TickSound(backgroundAudio::tone);trades=new BackgroundTrades(this::backgroundTrade,SystemClock::elapsedRealtime);lastPaperCloseId=MarketStore.latestPaperCloseId();NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);nm.createNotificationChannel(new NotificationChannel("prices","Background market monitoring",NotificationManager.IMPORTANCE_LOW));Intent launch=new Intent(this,MainActivity.class);PendingIntent open=PendingIntent.getActivity(this,0,launch,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);Intent stop=new Intent(this,PriceMonitorService.class).setAction("STOP");PendingIntent stopAction=PendingIntent.getService(this,1,stop,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);notificationBuilder=new Notification.Builder(this,"prices").setContentTitle("TwinTrade is monitoring markets").setContentText("Candles and paper positions continue in the background").setSmallIcon(android.R.drawable.ic_menu_recent_history).setContentIntent(open).setOngoing(true).addAction(new Notification.Action.Builder(null,"Stop monitoring",stopAction).build());Notification n=notificationBuilder.build();try{if(Build.VERSION.SDK_INT>=34)startForeground(42,n,ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);else startForeground(42,n);}catch(RuntimeException e){MarketStore.running=false;MarketStore.status="Background monitor unavailable · foreground prices active";android.util.Log.w("TwinTrade","Foreground registration rejected",e);stopped=true;jobs.shutdownNow();stopSelf();return;}wake=((PowerManager)getSystemService(POWER_SERVICE)).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,"TwinTrade:Prices");try{wake.acquire();}catch(SecurityException e){android.util.Log.w("TwinTrade","Wake lock unavailable",e);}}
 private synchronized void startMonitoring(){
  if(stopped||feed!=null)return;MarketStore.running=true;updateAudioOwnership();
  feed=new BackgroundPriceFeed(()->{try{jobs.execute(this::history);}catch(RejectedExecutionException ignored){}},SystemClock::elapsedRealtime,this::acceptBackgroundFrame);
  jobs.scheduleWithFixedDelay(()->{try{feed.poll();trades.poll(!MainActivity.visible&&!stopped);}catch(Exception e){android.util.Log.w("TwinTrade","Background watchdog failed",e);}},0,3,TimeUnit.SECONDS);
  jobs.scheduleWithFixedDelay(this::history,0,60,TimeUnit.SECONDS);jobs.scheduleWithFixedDelay(this::recoverBackgroundHolding,0,60,TimeUnit.SECONDS);
 }
 private void recoverBackgroundHolding(){if(stopped||MainActivity.visible)return;try{java.util.TreeSet<Integer> pairs=new java.util.TreeSet<>();JSONArray ps=new JSONObject(MarketStore.book()).getJSONArray("positions");for(int i=0;i<ps.length();i++){JSONObject p=ps.getJSONObject(i);if(p.getJSONObject("cost").optString("holdingSource").contains("market rates unavailable"))pairs.add(p.getInt("pair"));}Integer[] list=pairs.toArray(new Integer[0]);if(list.length==0)return;int start=holdingCursor%list.length;holdingCursor=(start+3)%list.length;for(int i=0;i<Math.min(3,list.length)&&!stopped;i++){int pair=list[(start+i)%list.length];for(String host:new String[]{"backend-polygon.gains.trade","backend-global.gains.trade","backend-polygon.gains.dev","backend-global.gains.dev"}){if(stopped)return;try{JSONObject response=getJson("https://"+host+"/api/holding-rates/3/"+pair+"?chainId=137");double[] rates=HoldingRateSnapshot.parse(response,System.currentTimeMillis());if(!stopped)MarketStore.recoverHoldingRates(pair,rates[0],rates[1],rates[2],rates[3],System.currentTimeMillis());break;}catch(Exception ignored){}}}}catch(Exception e){android.util.Log.w("TwinTrade","Background holding-rate recovery unavailable",e);}}
 private JSONObject getJson(String url)throws Exception{Exception last=null;for(String u:GainsEndpoints.candidates(url,System.currentTimeMillis())){try{JSONObject result=getJsonOnce(u);GainsEndpoints.success(u);return result;}catch(Exception e){last=e;GainsEndpoints.failure(u,System.currentTimeMillis());}}throw last;}
 private JSONObject getJsonOnce(String url)throws Exception{HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();c.setInstanceFollowRedirects(false);c.setConnectTimeout(15000);c.setReadTimeout(15000);try{if(c.getResponseCode()!=200)throw new IOException("HTTP "+c.getResponseCode());ByteArrayOutputStream bytes=new ByteArrayOutputStream();try(InputStream in=c.getInputStream()){byte[] b=new byte[8192];int n;while((n=in.read(b))!=-1){if(bytes.size()+n>16000000)throw new IOException("Public response exceeds 16 MB");bytes.write(b,0,n);}}return new JSONObject(bytes.toString("UTF-8"));}finally{c.disconnect();}}
 private void history(){synchronized(this){if(historyBusy||stopped)return;historyBusy=true;}boolean ok=false;try{
  try{JSONObject r=getJson("https://backend-pricing.eu.gains.trade/charts");JSONArray os=r.getJSONArray("opens"),hs=r.getJSONArray("highs"),ls=r.getJSONArray("lows"),cs=r.getJSONArray("closes");for(int i=0;i<Math.min(Math.min(os.length(),hs.length()),Math.min(ls.length(),cs.length()))&&i<=1000&&!stopped;i++){if(os.isNull(i)||hs.isNull(i)||ls.isNull(i)||cs.isNull(i))continue;MarketStore.seedOhlc(i,os.getDouble(i),hs.getDouble(i),ls.getDouble(i),cs.getDouble(i),r.optLong("time",System.currentTimeMillis()));ok=true;}}catch(Exception ignored){}
  for(java.util.Map.Entry<Integer,String> market:BackgroundHistoryPlan.markets(getSharedPreferences("market",0).getString("audioState","{}")).entrySet()){if(stopped)break;for(String chain:new String[]{"polygon","arbitrum"}){if(stopped)break;try{long to=System.currentTimeMillis(),from=to-300*60000L;JSONArray rows=getJson("https://api.gains.trade/v1/"+chain+"/markets/"+market.getValue()+"/candles?interval=1m&from="+from+"&to="+to).getJSONArray("data"),a=new JSONArray();for(int k=0;k<rows.length();k++){JSONObject r=rows.getJSONObject(k);double o=r.getDouble("open"),h=r.getDouble("high"),l=r.getDouble("low"),close=r.getDouble("close");long t=r.getLong("time");if(t>=1000000000L&&t<1000000000000L)t*=1000;t=t/60000*60000;if(t>0&&t<=to&&Double.isFinite(o)&&Double.isFinite(h)&&Double.isFinite(l)&&Double.isFinite(close)&&l>0&&h>=Math.max(o,close)&&l<=Math.min(o,close))a.put(new JSONObject().put("t",t).put("o",o).put("h",h).put("l",l).put("c",close).put("source","gains-history"));}if(stopped)return;MarketStore.merge(market.getKey(),a);MarketStore.save(true);ok=true;break;}catch(Exception ignored){}}}
  if(!stopped)MarketStore.historyStatus=ok?"Gains history + live · 1m":"History unavailable · cached/live candles shown";
 }finally{historyBusy=false;/* The fixed-delay job already retries every minute; never fork retry chains. */}}
 public int onStartCommand(Intent i,int flags,int id){
  if((i!=null&&"STOP".equals(i.getAction()))||!getSharedPreferences("market",0).getBoolean("keepAlive",true)){
   getSharedPreferences("market",0).edit().putBoolean("keepAlive",false).apply();
   stopMonitoring();stopSelf();return START_NOT_STICKY;
  }
  startMonitoring();
  if(i!=null&&"RECONNECT".equals(i.getAction())&&feed!=null)feed.reconnect();
  return stopped?START_NOT_STICKY:START_STICKY;
 }
 public IBinder onBind(Intent i){return null;}
 private synchronized void stopMonitoring(){
  if(stopped)return;stopped=true;
  if(feed!=null)feed.close();if(trades!=null)trades.stop();
  synchronized(audioLock){if(backgroundAudio!=null){backgroundAudio.close();backgroundAudio=null;}ownsAudio=false;}
  jobs.shutdownNow();MarketStore.running=false;MarketStore.status="Monitoring stopped";
  MarketStore.save(true);if(wake!=null&&wake.isHeld())wake.release();
 }
 public void onDestroy(){stopMonitoring();if(instance==this)instance=null;if(backgroundAudio!=null){backgroundAudio.close();backgroundAudio=null;}stopForeground(STOP_FOREGROUND_REMOVE);super.onDestroy();}
}
