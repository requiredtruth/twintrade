const {chromium}=require('playwright');const assert=require('node:assert/strict');const path=require('node:path');
(async()=>{const browser=await chromium.launch({headless:true,...(process.env.TWINTRADE_CHROME?{executablePath:process.env.TWINTRADE_CHROME}:{}),args:['--no-sandbox']});
 const errors=[];const page=await browser.newPage({viewport:{width:393,height:852}});page.on('pageerror',e=>errors.push(e.message));
 // Valid empty trader snapshots prevent unrelated offline retry notices from racing timer assertions.
 await page.route('https://**/*',r=>r.request().url().includes('/open-trades')?r.fulfill({json:[]}):r.abort());await page.addInitScript(()=>{window.WebSocket=class{constructor(url){this.readyState=1;this.url=url;setTimeout(()=>this.onopen?.({}),0);if(url.includes('backend-pricing'))setTimeout(()=>this.onmessage?.({data:JSON.stringify({m:[0,84610,1,2682,300,84610,313,2682],i:[0,84612,1,2683],t:Date.now()})}),500)}close(){this.readyState=3}send(){}};});
 await page.goto('file://'+path.resolve('dist/TwinTrade.html'));await page.waitForTimeout(1100);await page.evaluate(()=>paperDelayMs=()=>0);
 await page.evaluate(()=>recordLiveError('USDC approval',Object.assign(Error('processing response error'),{code:'SERVER_ERROR',error:{message:'RPC unavailable https://rpc.example.test/private-credential'}})));
 await page.click('#statsOpen');
 const [download]=await Promise.all([page.waitForEvent('download'),page.click('#exportErrorsStats')]);
 assert.equal(download.suggestedFilename(),'TwinTrade-errors.txt');
 const report=require('node:fs').readFileSync(await download.path(),'utf8');
 assert(report.includes('USDC approval'));assert(report.includes('SERVER_ERROR'));assert(!report.includes('private-credential'));
 await page.click('#closeStats');
 await page.fill('#dollars','2.123456');
 assert((await page.locator('#quote').textContent()).includes('$2.123456 collateral'));
 await page.locator('#sizeSlider').evaluate(el=>{el.value='12.5';el.dispatchEvent(new Event('input'));});
 assert.equal(await page.inputValue('#dollars'),'');
 assert((await page.locator('#sizeReadout').textContent()).includes('12.5%'));
 await page.locator('#levSlider').evaluate(el=>{el.value='250.125';el.dispatchEvent(new Event('input'));});
 assert.equal(await page.inputValue('#lev'),'250.125');
 await page.selectOption('#amount','10');
 await page.fill('#lev','200');
 for(const [key,body] of [['Chart','chartwrap'],['Positions','positions'],['Ticket','ticketBody']]){
   const toggle=page.locator('#toggle'+key);
   await toggle.click();assert.equal(await toggle.textContent(),'+');
   assert.equal(await page.locator('#'+body).getAttribute('hidden'),'');
   await toggle.click();assert.equal(await toggle.textContent(),'−');
 }
 const grip=await page.locator('#resizePositions').boundingBox();
 await page.mouse.move(grip.x+grip.width/2,grip.y+grip.height/2);
 await page.mouse.down();await page.mouse.move(grip.x+grip.width/2,grip.y+grip.height/2+35,{steps:4});await page.mouse.up();
 assert(Number(await page.evaluate(()=>JSON.parse(localStorage.terminalLayout).sizes.Positions))>=24);
 await page.locator('#moveChart').press('ArrowDown');
 assert.deepEqual(await page.evaluate(()=>JSON.parse(localStorage.terminalLayout).order),['Positions','Chart','Ticket']);
 await page.locator('#moveChart').press('ArrowUp');
 await page.evaluate(()=>document.getElementById('resetTerminalLayout').click());
 // Legend shares every chart line style and stays reachable in both orientations.
 for(const viewport of [{width:393,height:852},{width:852,height:393}]){
  await page.setViewportSize(viewport);await page.click('#legendOpen');
  assert(await page.locator('#legendDialog').isVisible());
  assert.equal(await page.locator('.legend-row').count(),14);
  assert(await page.evaluate(()=>Object.values(LINE_STYLE).every((style,i)=>{const line=document.querySelectorAll('.legend-row line')[i];return line.getAttribute('stroke')===style.color&&line.getAttribute('stroke-dasharray')===style.dash.join(' ')})));
  assert((await page.locator('#legendRows').textContent()).includes('Public short average liquidation'));
  assert(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));
  await page.click('#closeLegend');assert(!(await page.locator('#legendDialog').isVisible()));
 }
 await page.setViewportSize({width:393,height:852});
 const accountMetrics=await page.evaluate(()=>{
   renderAccountMetrics([{amount:20}],10);
   return ['netBalancePct','netMarginPct','openTradeCount'].map(id=>$(id).textContent);
 });
 assert.deepEqual(accountMetrics,['+8.33%','+50.00%','1']);
 await page.evaluate(()=>render());
 assert.equal(await page.locator('#price').textContent(),'$84610.00');assert((await page.locator('#positionPnlSummary').textContent()).includes('Long net'));await page.click('#long');await page.waitForTimeout(300);assert((await page.locator('#positions').textContent()).includes('L'));
 // Exact leverage entry and quick limits across crypto, commodities, stocks and forex.
 for(const [pi,max,min] of [[2,150,1.1],[90,250,1.1],[58,4,1.1],[21,1000,10],[0,500,1.1]]){await page.evaluate(pi=>{pair=pi;render()},pi);assert.equal(await page.locator('#lev').getAttribute('max'),String(max));assert.equal(await page.locator('#lev').getAttribute('min'),String(min));const choices=await page.locator('#levPresets option').evaluateAll(os=>os.map(o=>o.value));assert(choices.includes(String(max)));assert(choices.includes(String(min)));await page.selectOption('#levPresets',String(max));assert.equal(await page.inputValue('#lev'),String(max));}
 await page.fill('#lev','1.1');await page.evaluate(()=>{prices[0]=84610;last[0]=Date.now();marketFees[0]={feePct:0,spreadPct:0,borrowHourly:0,fundLongHourly:0,fundShortHourly:0,at:Date.now()};render()});await page.click('#long');await page.waitForFunction(()=>book.positions.at(-1).lev===1.1);assert.equal(await page.evaluate(()=>book.positions.at(-1).lev),1.1);assert((await page.locator('#positions').textContent()).includes('1.1×'));
 await page.evaluate(()=>{pair=2;prices[2]=10;last[2]=Date.now();marketFees[2]={feePct:0,spreadPct:0,borrowHourly:0,fundLongHourly:0,fundShortHourly:0,at:Date.now()};render()});
 for(const lev of ['150','149.999']){await page.fill('#lev',lev);await page.click('#long');await page.waitForFunction(lev=>book.positions.at(-1).lev===+lev,lev);assert.equal(await page.evaluate(()=>book.positions.at(-1).lev),+lev);}
 const count=await page.evaluate(()=>book.positions.length);await page.fill('#lev','150.001');await page.click('#long');assert.equal(await page.evaluate(()=>book.positions.length),count,'above cap rejected');
 await page.evaluate(()=>{TradeConfig.discover([{pairIndex:2,symbol:'LINK/USD',minLeverage:1.1,maxLeverage:125}]);render()});assert.equal(await page.inputValue('#lev'),'125');assert.equal(await page.locator('#lev').getAttribute('max'),'125');await page.evaluate(()=>{pair=0;render()});await page.fill('#lev','200');
 // Combined BTC restores 500× through the actual DEGEN market, and owns
 // entry / LIQ tags remain on the BTC chart even without public overlays.
 await page.evaluate(()=>{window.ownLabels=[];const proto=CanvasRenderingContext2D.prototype,original=proto.fillText;proto.fillText=function(text,x,y,...rest){ownLabels.push({text,y});return original.call(this,text,x,y,...rest)};});
 await page.fill('#lev','500');
 // Real browser quote and position use DEGEN rates, including leveraged credit.
 await page.evaluate(()=>{marketFees[300]={feePct:.02,spreadPct:0,borrowHourly:.001,fundLongHourly:.002,fundShortHourly:-.004,at:Date.now()};render()});
 assert((await page.locator('#quote').textContent()).includes('1.5000% collateral/h'));assert((await page.locator('#quote').textContent()).includes('/h credit'));
 await page.click('#long');await page.waitForTimeout(300);
 assert.equal(await page.evaluate(()=>book.positions.at(-1).pair),300);assert.equal(await page.evaluate(()=>book.positions.at(-1).lev),500);assert.equal(await page.evaluate(()=>book.positions.at(-1).cost.fundingSide),.002);assert((await page.locator('#positions').textContent()).includes('BTCDEGEN'));assert((await page.locator('#quote').textContent()).includes('Order BTCDEGEN'));
 await page.evaluate(()=>{$('overlay').checked=false;draw();});assert(await page.evaluate(()=>ownLabels.some(o=>o.text.startsWith('L LIQ D')&&o.y>=0&&o.y<=$('chart').getBoundingClientRect().height)),'own BTCDEGEN LIQ remains visible on BTC');await page.evaluate(()=>{$('overlay').checked=true;});await page.fill('#lev','200');
 // Distant entry and liquidation labels appear after vertical panning, without a feed reload.
 await page.evaluate(()=>{window.panFixture={book,candles:candles[0],publicTrades,view};book={cash:100,positions:[],history:[]};const px=priceOf(0);candles[0]=[{t:Math.floor(Date.now()/60000)*60000,o:px,h:px+2,l:px-2,c:px}];publicTrades=[{id:'distant',pair:300,isOpen:true,long:true,lev:500,amount:123,entry:px+100,liq:px+100.1,kind:'public'}];view={span:75,off:0,yOff:0};renderPublic();ownLabels=[];draw()});
 assert(!(await page.evaluate(()=>ownLabels.some(o=>o.text.startsWith('L 500× $123 D')))));
 // Minimum price padding is 0.03%, so compute the actual unpanned span.
 await page.evaluate(()=>{const px=priceOf(0),span=4+2*Math.max(.6,(px+2)*.0003);view.yOff=100/span;ownLabels=[];draw()});
 assert(await page.evaluate(()=>ownLabels.some(o=>o.text.startsWith('L 500× $123 D')&&o.y>=0&&o.y<=$('chart').getBoundingClientRect().height)));assert(await page.evaluate(()=>ownLabels.some(o=>o.text.startsWith('L LIQ 500× $123 D'))));
 await page.evaluate(()=>{book=panFixture.book;candles[0]=panFixture.candles;publicTrades=panFixture.publicTrades;view=panFixture.view;renderPublic();draw()});
 for(const [w,h]of [[393,852],[852,393],[360,640],[740,360],[393,852]]){await page.setViewportSize({width:w,height:h});await page.waitForTimeout(150);
 const chartBefore=await page.locator('#chart').boundingBox();
 await page.evaluate(()=>setLoadBar(100,'1248 open trades synced'));
 const chartDuring=await page.locator('#chart').boundingBox();assert.deepEqual(chartDuring,chartBefore,'sync message must not shift/resize chart');
 await page.evaluate(()=>{loadingTasks.clear();loadingProgress('history',25,'History 1/4 pages');loadingProgress('traders',60,'POLYGON 60/100');});
 assert.equal(await page.locator('#loadingProgress').isVisible(),true);assert((await page.locator('#loadingDetails').textContent()).includes('History 1/4 pages'));
 assert.deepEqual(await page.locator('#chart').boundingBox(),chartBefore,'progress overlay keeps chart fixed');
 const progressBox=await page.locator('#loadingProgress').boundingBox();assert(progressBox.y>=chartBefore.y&&progressBox.y<chartBefore.y+5,'progress is at chart top');
 await page.evaluate(()=>{loadingProgress('history',100,'History ready',true);});assert((await page.locator('#loadingDetails').textContent()).includes('POLYGON 60/100'));
 await page.evaluate(()=>{loadingProgress('traders',100,'Traders ready',true);});
 const messageBox=await page.locator('#syncMessage').boundingBox(),feesBox=await page.locator('#fees').boundingBox();assert(messageBox.y+messageBox.height<=feesBox.y+1,'sync message above borrowing text');
 await page.evaluate(()=>setLoadBar(100,''));assert.deepEqual(await page.locator('#chart').boundingBox(),chartBefore,'clearing message keeps chart fixed');await page.screenshot({path:'build/mobile-qa.png'});for(const id of ['menu','settings','long','short']){const b=await page.locator('#'+id).boundingBox();assert(b&&b.x>=0&&b.y>=0&&b.x+b.width<=w+1&&b.y+b.height<=h+1,`${id} outside ${w}x${h}: ${JSON.stringify(b)}`)}assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth),false,'No horizontal overflow');}
 await page.evaluate(()=>setLoadBar(100,'Trades synced'));await page.waitForTimeout(2200);await page.evaluate(()=>setLoadBar(100,'New trades synced'));await page.waitForTimeout(1500);assert.equal(await page.locator('#syncMessage').isVisible(),true,'old timer does not clear new sync text');await page.waitForTimeout(2100);assert.equal(await page.locator('#syncMessage').isVisible(),false,'completed sync text expires');
 // Frequent backend refreshes and failed history retries must stay silent.
 await page.evaluate(async()=>{loadingTasks.clear();clearTimeout(progressHideT);$('loadingProgress').hidden=true;for(let i=0;i<3;i++){await loadHistory();await loadPublicSnapshot();}});
 assert.equal(await page.locator('#loadingProgress').isVisible(),false,'routine refresh cannot resurrect progress');
 await page.evaluate(()=>$('retryPublic').onclick());await page.waitForFunction(()=>!snapshotBusy);assert.equal(await page.locator('#loadingProgress').isVisible(),true,'manual Reload still shows progress');
 await page.evaluate(()=>{view={span:250,off:15,yOff:2};selectedPublic='test'});await page.click('#zoomMenu');await page.click('#resetChart');await page.click('#zoomMenu');assert.deepEqual(await page.evaluate(()=>({...view,selectedPublic})),{span:75,off:0,yOff:0,selectedPublic:null});
 await page.click('#menu');await page.click('#portfolioOpen');assert.equal(await page.locator('#accountPanel').isVisible(),true);assert((await page.locator('#accountRows').textContent()).includes('L'));await page.click('#accountHistory');assert((await page.locator('#accountTitle').textContent()).includes('Past trades'));await page.click('#closeAccount');
 await page.evaluate(()=>{last[0]=Date.now()-30000;renderSyncStatus()});assert.equal(await page.locator('#desync').isVisible(),true);await page.evaluate(()=>{last[0]=Date.now();renderSyncStatus()});assert.equal(await page.locator('#desync').isVisible(),false);
 await page.evaluate(()=>{last[0]=Date.now()-29900;renderSyncStatus()});assert.equal(await page.locator('#desync').isVisible(),false);
 await page.evaluate(()=>{publicTrades=[{id:'test',isOpen:true,kind:'public',net:'POLYGON',pair:0,long:true,lev:100,amount:10,entry:84000,liq:83000}];renderPublic()});await page.click('#statsOpen');assert.equal(await page.locator('#statsPanel').isVisible(),true);assert((await page.locator('#statsRows').textContent()).includes('$84000.00'));assert((await page.locator('#statsRows').textContent()).includes('$83000.00'));await page.click('#connectionDiagnostics summary');assert((await page.locator('#connectionRows').textContent()).includes('Price oracle'));assert((await page.locator('#connectionRows').textContent()).includes('Polygon trades'));assert.equal(await page.locator('#connectionDiagnostics').evaluate(el=>el.scrollWidth<=el.clientWidth),true,'connection diagnostics fit phone width');
 await page.evaluate(()=>{publicTrades[0].entry=85000;renderPublic();renderStats()});assert((await page.locator('#statsRows').textContent()).includes('$85000.00'));for(const [w,h]of [[360,640],[740,360]]){await page.setViewportSize({width:w,height:h});assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth),false)}await page.evaluate(()=>{publicTrades[0].liq=undefined;renderPublic();renderStats()});assert((await page.locator('#statsRows').textContent()).includes('EST'));assert((await page.locator('#statsRows').textContent()).includes('$84235.00'));assert((await page.locator('#statsRows').textContent()).includes('1 estimated'));
 await page.evaluate(()=>{const now=Date.now();candles[0]=[{t:now,o:84000,h:86000,l:83000,c:85000}];prices[0]=85000;window.avgTexts=[];const ctx=document.getElementById('chart').getContext('2d'),old=ctx.fillText.bind(ctx);ctx.fillText=(s,...a)=>{avgTexts.push(s);old(s,...a)};draw()});assert((await page.evaluate(()=>avgTexts)).some(s=>s.includes('AVG LIQ EST L ALL')&&s.includes('$84235.00')),'all-leverage estimate stroked and labeled');
 await page.click('#closeStats');assert.equal(await page.locator('#statsPanel').isVisible(),false);await page.setViewportSize({width:393,height:852});
 assert.equal(await page.evaluate(()=>typeof checkDanger),'undefined');assert.equal(await page.evaluate(()=>safeLiq({kind:'live',liq:83000})),83000);
 // A profitable price move can still have negative net P&L; own labels must agree.
 await page.evaluate(()=>{const now=Date.now();mode='paper';pair=0;prices[0]=84670.18;last[0]=now;const p=Engine.open(0,true,100,200,84631.5684,{fee:.035,slip:.005,borrow:0,funding:0,liq:90},now);book={cash:0,positions:[p],history:[]};const ctx=document.getElementById('chart').getContext('2d');window.chartTexts=[];const old=ctx.fillText.bind(ctx);ctx.fillText=(s,...args)=>{chartTexts.push(s);old(s,...args)};candles[0]=[{t:Math.floor(now/60000)*60000,o:84630,h:84680,l:84620,c:84670.18,source:'gains-live'}];render();});
 const feeCheck=await page.evaluate(()=>({card:document.getElementById('positions').textContent,labels:chartTexts,net:'-$'+Math.abs(Engine.value(book.positions[0],prices[0]).net).toFixed(2)}));
 assert(feeCheck.card.includes('Open fee $7.00'));assert(feeCheck.card.includes('Close est. $7.00'));assert(feeCheck.labels.some(s=>s.includes(' NET')));assert(feeCheck.labels.includes(feeCheck.net),'own chart label shows net, not gross');
 await page.evaluate(()=>{const now=Date.now();book.positions=[Engine.open(0,false,100,200,84670.18,{fee:.035,slip:0,borrow:.001,funding:0,fundingSide:-.004,liq:90},now-3600000)];render();});
 assert((await page.locator('#positions').textContent()).includes('Hold gain'));assert.deepEqual(await page.locator('#positions small b.positive').allTextContents(),['$0.60','$0.80'],'holding total and funding credit are green');assert((await page.locator('#positions').textContent()).includes('Borrow $0.20'));
 await page.evaluate(()=>{marketFees[0]={feePct:.02,borrowHourly:.001,fundLongHourly:.002,fundShortHourly:-.004,at:Date.now()};const l=paperCosts(0,true),s=paperCosts(0,false);if(l.fee!==.02||l.fundingSide!==.002||s.fundingSide!==-.004)throw Error('Polygon per-side rates not used');delete marketFees[0];});
 await page.click('#settings');assert.equal(await page.locator('#config').evaluate(el=>el.open),true);await page.click('#closeConfig');assert.equal(await page.locator('#config').evaluate(el=>el.open),false);
 // Android bridge exists but background monitor is off: foreground recovery must still connect.
 const nativePage=await browser.newPage({viewport:{width:393,height:852}});nativePage.on('pageerror',e=>errors.push(e.message));await nativePage.route('https://**/*',r=>r.abort());
 await nativePage.addInitScript(()=>{let book={cash:100,positions:[],history:[]},quotes={},times={},indexes={},indexTimes={};window.nativeFrames=0;window.WebSocket=class{constructor(url){this.readyState=1;this.url=url;setTimeout(()=>this.onopen?.({}),0);if(url.includes('backend-pricing'))setTimeout(()=>this.onmessage?.({data:JSON.stringify({m:[0,84610,1,2682],i:[0,84612,1,2683],t:Date.now()})}),100)}close(){this.readyState=3}send(){}};window.Feed={seed(raw){book=JSON.parse(raw)},paper(){return JSON.stringify(book)},snapshot(){return JSON.stringify({running:false,keepAlive:false,status:'Monitoring stopped',prices:[quotes[0]||0,quotes[1]||0],times:[times[0]||0,times[1]||0],indexPrices:indexes,indexTimes,candles:[[],[]]})},acceptPriceFrame(raw){const f=JSON.parse(raw);nativeFrames++;for(let k=0;k<f.m.length;k+=2){quotes[f.m[k]]=f.m[k+1];times[f.m[k]]=f.t}for(let k=0;k<f.i.length;k+=2){indexes[f.i[k]]=f.i[k+1];indexTimes[f.i[k]]=f.t}return 4},open(pair,long,percent,lev,costs){if(!quotes[pair]||Date.now()-times[pair]>=5000)return 'Waiting for fresh Gains price';const amount=book.cash*percent/100;book.positions.push({id:'native-test',pair,long,amount,lev,entry:quotes[pair],cost:JSON.parse(costs),kind:'paper',opened:Date.now()});book.cash-=amount;return 'OK'}};});
 await nativePage.goto('file://'+path.resolve('dist/TwinTrade.html'));await nativePage.waitForTimeout(700);assert.equal(await nativePage.locator('#price').textContent(),'$84610.00','bridge with background off recovers foreground prices');assert.equal(await nativePage.evaluate(()=>nativeFrames),1,'foreground frame reaches native ledger');assert.equal(await nativePage.locator('#keepAlive').isChecked(),false,'does not silently enable background monitoring');await nativePage.click('#long');await nativePage.waitForTimeout(300);assert((await nativePage.locator('#positions').textContent()).includes('L'),'native paper order uses recovered quote');await nativePage.click('#statsOpen');assert((await nativePage.locator('#statsTransport').textContent()).includes('Foreground socket connected'));await nativePage.click('#reconnectFeed');await nativePage.waitForTimeout(300);assert.equal(await nativePage.evaluate(()=>nativeFrames),2,'manual reconnect receives a replacement live frame');await nativePage.close();
 // Profile must open, render known history, filter ranges and fit both orientations.
 await page.evaluate(()=>{window.savedProfileHistory=book.history;const now=Date.now();book.history=[{id:'profile-1',amount:100,net:10,closed:now-1000,opened:now-3600000,long:true},{id:'profile-2',amount:100,net:-5,closed:now,opened:now-1000,long:false}];});
 for(const viewport of [{width:393,height:852},{width:852,height:393}]){await page.setViewportSize(viewport);await page.click('#profileOpen');assert(await page.locator('#profileDialog').isVisible());assert.equal(await page.locator('#profileStats>div').count(),18);assert((await page.locator('#profileScope').textContent()).includes('2 settled trades'));assert.equal(await page.locator('#profileChart svg').count(),1);assert(await page.evaluate(()=>document.getElementById('profileDialog').scrollWidth<=document.getElementById('profileDialog').clientWidth));await page.selectOption('#profileRange','7');await page.click('#closeProfile');}
 await page.evaluate(()=>{book.history=[];});await page.click('#profileOpen');assert((await page.locator('#profileChart').textContent()).includes('No settled trades'));await page.click('#closeProfile');await page.evaluate(()=>{book.history=savedProfileHistory;render();});
 // Exercise the submenu and real OHLC aggregation at phone width.
 await page.setViewportSize({width:393,height:852});await page.click('#zoomMenu');assert.equal(await page.locator('#zoomPanel').isVisible(),true);
 await page.evaluate(()=>{window.originalFetchHistory=fetchHistoryChain;window.historyPages=0;fetchHistoryChain=async(chain,sym,from,to)=>{historyPages++;const rows=[];for(let t=Math.ceil(from/60000)*60000;t<=to;t+=60000)rows.push({t,o:85000,h:85100,l:84900,c:85010,source:'gains-history'});return {rows,chain};};});
 await page.click('[data-range="1440"]');await page.waitForTimeout(200);assert.equal(await page.evaluate(()=>view.span),1440);assert((await page.evaluate(()=>candles[0].length))>=1440,'day preset fetches more than old 300-minute cap');assert.equal(await page.evaluate(()=>historyPages),5);
 await page.click('[data-interval="60"]');assert((await page.evaluate(()=>chartBars().length))<=25,'hour candles aggregate OHLC');
 await page.click('#zoomMax');assert.equal(await page.evaluate(()=>view.span),10);await page.click('#zoomMin');await page.waitForTimeout(200);assert.equal(await page.evaluate(()=>view.span),10080);
 assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth),false,'zoom submenu fits phone width');
 await page.evaluate(()=>{fetchHistoryChain=originalFetchHistory;view={span:1440,off:3,yOff:0};chartInterval=60;checkpointSession();});await page.reload();await page.waitForTimeout(800);assert.deepEqual(await page.evaluate(()=>({pair,span:view.span,off:view.off,interval:chartInterval})),{pair:0,span:1440,off:3,interval:60});assert((await page.evaluate(()=>candles[0].length))>=1440,'chart history survives recreation');
 await page.click('#zoomMenu');await page.click('#resetChart');await page.click('#zoomMenu');
 // Chart dialog beside Stats preserves chart geometry and updates after pan/rotation.
 assert.equal(await page.locator('#chartReadout').evaluate(el=>el.closest('dialog').id),'chartInfoDialog');
 const infoBefore=await page.locator('#chart').boundingBox();await page.click('#chartInfoOpen');assert.equal(await page.locator('#chartInfoDialog').evaluate(el=>el.open),true);assert.deepEqual(await page.locator('#chart').boundingBox(),infoBefore);
 assert.equal(await page.locator('#chartInfoOpen').evaluate(el=>el.previousElementSibling.id),'ratiosOpen');
 await page.evaluate(()=>{const t=new Date(2026,9,5,23,0).getTime();candles[0]=Array.from({length:1440},(_,i)=>({t:t+i*60000,o:85000,h:85100,l:84900,c:85010,source:'gains-history'}));view={span:1440,off:0,yOff:0};chartInterval=60;draw()});
 assert((await page.locator('#chartDetails').textContent()).includes('Range 1d · Candles 1h'));
 assert((await page.locator('#chartRange').textContent()).includes('Oct 5'));assert((await page.locator('#chartRange').textContent()).includes('Oct 6'));
 for(const [width,height]of [[360,640],[852,393],[393,852]]){await page.setViewportSize({width,height});await page.evaluate(()=>draw());assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth),false);const readout=await page.locator('#chartInfoDialog').boundingBox();assert(readout.x>=0&&readout.y>=0&&readout.x+readout.width<=width+1&&readout.y+readout.height<=height+1);assert((await page.locator('#chart').boundingBox()).height>70);}
 await page.evaluate(()=>{view.span=60;view.off=300;chartInterval=0;draw()});assert((await page.locator('#chartDetails').textContent()).includes('Past 5h'));await page.screenshot({path:'build/chart-time-qa.png'});await page.click('#closeChartInfo');assert.equal(await page.locator('#chartInfoDialog').evaluate(el=>el.open),false);const closedInfo=await page.locator('#chart').boundingBox();await page.click('#chartInfoOpen');await page.keyboard.press('Escape');assert.equal(await page.locator('#chartInfoDialog').evaluate(el=>el.open),false);assert.deepEqual(await page.locator('#chart').boundingBox(),closedInfo);
 await page.evaluate(()=>{view={span:75,off:0,yOff:0};draw()});
 // Real horizontal pointer drags follow the finger and preserve the right gap.
 const chartBox=await page.locator('#chart').boundingBox();const dragY=chartBox.y+chartBox.height/2;
 await page.evaluate(()=>{view.off=100;draw()});
 await page.mouse.move(chartBox.x+120,dragY);await page.mouse.down();await page.mouse.move(chartBox.x+180,dragY,{steps:5});await page.mouse.up();const olderOffset=await page.evaluate(()=>view.off);assert(olderOffset>100);
 await page.mouse.move(chartBox.x+180,dragY);await page.mouse.down();await page.mouse.move(chartBox.x+120,dragY,{steps:5});await page.mouse.up();assert.equal(await page.evaluate(()=>view.off),100);
 for(const [width,height] of [[360,640],[852,393],[393,852]]){await page.setViewportSize({width,height});const geometry=await page.evaluate(()=>chartPlot($('chart').getBoundingClientRect().width));assert(geometry.right-geometry.candleRight>=40);assert(geometry.right-geometry.candleRight<=80);}
 await page.evaluate(()=>{view.off=0;draw()});await page.screenshot({path:'build/chart-navigation-qa.png'});
 // L/S button beside Stats opens live total/tier ratios without resizing the chart.
 assert.equal(await page.locator('#ratioPanel').evaluate(el=>el.closest('dialog').id),'ratiosDialog');assert.equal(await page.locator('#ratiosOpen').evaluate(el=>el.previousElementSibling.id),'statsOpen');
 await page.evaluate(()=>{window.ratioFixture=publicTrades;pair=0;publicTrades=[{pair:0,isOpen:true,long:true,lev:100,amount:10},{pair:300,isOpen:true,long:true,lev:500,amount:2},{pair:0,isOpen:true,long:false,lev:100,amount:20}];statsRevision++;renderRatios()});
 const ratioChart=await page.locator('#chart').boundingBox();await page.click('#ratiosOpen');assert.equal(await page.locator('#ratiosDialog').evaluate(el=>el.open),true);assert.deepEqual(await page.locator('#chart').boundingBox(),ratioChart);assert((await page.locator('#ratioRows .ratio-card').first().textContent()).includes('L 66.67% / S 33.33%'));assert((await page.locator('#ratioRows').textContent()).includes('500'));
 await page.selectOption('#ratioBasis','value');assert((await page.locator('#ratioRows .ratio-card').first().textContent()).includes('L 50.00% / S 50.00%'));
 await page.evaluate(()=>{publicTrades.push({pair:0,isOpen:true,long:false,lev:100,amount:20});statsRevision++;renderRatios()});assert((await page.locator('#ratioRows .ratio-card').first().textContent()).includes('L 33.33% / S 66.67%'));
 for(const [width,height]of [[360,640],[852,393],[393,852]]){await page.setViewportSize({width,height});await page.waitForTimeout(100);const box=await page.locator('#ratiosDialog').boundingBox();assert(box.x>=0&&box.y>=0&&box.x+box.width<=width+1&&box.y+box.height<=height+1);assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth),false);}
 await page.screenshot({path:'build/ratios-dialog-qa.png'});await page.click('#closeRatios');assert.equal(await page.locator('#ratiosDialog').evaluate(el=>el.open),false);const ratioClosed=await page.locator('#chart').boundingBox();await page.click('#ratiosOpen');await page.keyboard.press('Escape');assert.equal(await page.locator('#ratiosDialog').evaluate(el=>el.open),false);assert.deepEqual(await page.locator('#chart').boundingBox(),ratioClosed);
 await page.evaluate(()=>{publicTrades=ratioFixture;$('ratioBasis').value='count';statsRevision++;renderRatios()});
 // Six close choices; current-coin selection preserves other-coin positions.
 await page.evaluate(()=>{const now=Date.now(),cost={fee:.035,slip:0,borrow:.07,funding:0,liq:90};mode='paper';pair=0;prices[0]=100.2698;last[0]=now;prices[1]=100;last[1]=now;book={cash:0,positions:[Engine.open(0,true,100,200,100,cost,now-3600000),Engine.open(1,false,10,10,100,{...cost,fee:0,borrow:0},now)],history:[]};render();});
 await page.locator('[data-exits]').first().click();
 assert(await page.locator('#exitRules').isVisible());
 await page.fill('#exitTP','101');await page.fill('#exitSL','98');await page.fill('#exitTrail','2');await page.fill('#exitATR','3');
 await page.evaluate(()=>{last[0]=Date.now();});
 await page.click('#savePaperExits');
 assert(!(await page.locator('#exitRules').isVisible()));
 assert.deepEqual(await page.evaluate(()=>{const {tp,sl,trail,atr}=book.positions[0].exits;return [tp,sl,trail,atr];}),[101,98,2,3]);
 await page.click('#closeMenu');assert.equal(await page.locator('#closeMenuDialog .close-options button').count(),6);await page.click('#closeCurrentLongs');await page.waitForFunction(()=>book.positions.length===1||(book.pending||[]).some(q=>q.action==='close'));await page.evaluate(()=>{processBrowserPaper(Date.now()+31000);render()});assert.equal(await page.locator('#settlementDialog').evaluate(el=>el.open),true);assert((await page.locator('#settlementRows').textContent()).includes('Holding cost deducted'));const delayedReceipt=await page.evaluate(()=>book.history[0].settlement);assert(delayedReceipt.hold>=14&&delayedReceipt.hold<=14.13,'holding accrues during at most 31 delayed seconds');assert((await page.locator('#settlementRows').textContent()).includes('$7.00'));assert((await page.locator('#settlementTotal').textContent()).includes(delayedReceipt.payout.toFixed(2)));assert.equal(await page.evaluate(()=>book.positions.length),1);assert.equal(await page.evaluate(()=>book.positions[0].pair),1);
 await page.waitForTimeout(4200);assert.equal(await page.locator('#settlementDialog').evaluate(el=>el.open),true,'receipt persists until dismissed');
 for(const [w,h]of [[360,640],[740,360],[393,852]]){await page.setViewportSize({width:w,height:h});const b=await page.locator('#settlementDialog').boundingBox();assert(b.x>=0&&b.y>=0&&b.x+b.width<=w+1&&b.y+b.height<=h+1,'receipt dialog fits rotated phone');assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth),false);}
 await page.screenshot({path:'build/settlement-qa.png'});await page.click('#dismissSettlement');assert.equal(await page.locator('#settlementDialog').evaluate(el=>el.open),false);
 // Real audio context recovery, saved mute and explicit enable/test.
 await page.evaluate(()=>{soundOn=true;tickOn=true;ensureAudio()});await page.waitForFunction(()=>audioCtx.state==='running');
 await page.evaluate(()=>audioCtx.suspend());assert.equal(await page.evaluate(()=>audioCtx.state),'suspended');await page.evaluate(()=>onAppResume());await page.waitForFunction(()=>audioCtx.state==='running');
 await page.evaluate(()=>{soundOn=false;tickOn=false;persist()});await page.evaluate(()=>audioCtx.suspend());await page.evaluate(()=>onAppResume());assert.equal(await page.evaluate(()=>audioCtx.state),'suspended','saved mute stays muted on resume');
 await page.click('#settings');assert.equal(await page.locator('#soundLevel option').count(),3);await page.selectOption('#soundLevel','0.7');assert.equal(await page.locator('#soundLevel').inputValue(),'0.7');await page.click('#enableAudio');await page.waitForFunction(()=>audioCtx.state==='running');assert.equal(await page.locator('#soundOn').isChecked(),true);assert.equal(await page.locator('#tickOn').isChecked(),true);assert((await page.locator('#audioStatus').textContent()).includes('Events on'));
 await page.evaluate(()=>audioCtx.close());await page.click('#enableAudio');await page.waitForFunction(()=>audioCtx.state==='running');await page.click('#closeConfig');
 // Public event audio and replacing banner occupy the same slot as loading.
 await page.click('#chart',{position:{x:15,y:45}});
 await page.evaluate(()=>{window.publicTones=[];window.originalPublicTone=tone;tone=(...args)=>{publicTones.push(args);originalPublicTone(...args)};pair=0;wallet=null;fullyLoaded=true;quietEvents=false;soundOn=true;publicNoticeState.clear();clearTradeEvent();window.bannerSerial=0;});
 const signatures=new Set();let eventIndex=0;
 for(const action of ['open','close','liq'])for(const long of [true,false]){
  const signature=await page.evaluate(({action,long,id})=>{publicTones=[];notifyPublicTrade({id:'POLYGON:browser:'+id,user:'browser',net:'POLYGON',pair:long?0:300,long,lev:500,amount:123,entry:84610},action);return JSON.stringify(publicTones)},{action,long,id:eventIndex++});signatures.add(signature);
  assert((await page.locator('#tradeEvent').textContent()).includes((action==='liq'?'LIQ':action.toUpperCase())+' '+(long?'L':'S')));assert.equal(await page.locator('#tradeEvent').count(),1);
 }
 assert.equal(signatures.size,6,'six distinct public audio patterns');assert.equal(await page.evaluate(()=>audioCtx.state),'running','public audio unlocked by touch');
 for(const [width,height]of [[393,852],[852,393],[740,360],[393,852]]){await page.setViewportSize({width,height});await page.waitForTimeout(100);const before=await page.locator('#chart').boundingBox();await page.evaluate(()=>{notifyPublicTrade({id:'POLYGON:rotation:'+bannerSerial++,user:'browser',pair:0,long:true,lev:200,amount:10,entry:84610},'open');loadingProgress('bannerTest',50,'Loading test')});const banner=await page.locator('#tradeEvent').boundingBox(),progress=await page.locator('#loadingProgress').boundingBox();assert.equal(banner.y,before.y);assert.equal(banner.y,progress.y);assert.deepEqual(await page.locator('#chart').boundingBox(),before,'event banner never shifts chart');}
 await page.evaluate(()=>{clearTimeout(progressHideT);loadingTasks.clear();$('loadingProgress').hidden=true;soundOn=false;publicTones=[];notifyPublicTrade({id:'POLYGON:muted',pair:0,long:false,lev:500,amount:10,entry:84610},'liq')});assert.equal(await page.locator('#tradeEvent').isVisible(),true);assert.equal(await page.evaluate(()=>publicTones.length),0,'mute silences public tones');await page.waitForTimeout(4700);assert.equal(await page.locator('#tradeEvent').isVisible(),true,'latest event persists past the old expiry');assert((await page.locator('#tradeEvent').textContent()).includes('LIQ S'));assert.equal(await page.locator('#loadingProgress').isVisible(),false,'persistent event cannot resurrect loading progress');
 // Off-chart events cannot replace BTC text or sound; chart switches restore only matching events.
 const btcBanner=await page.locator('#tradeEvent').textContent();
 await page.evaluate(()=>{pair=0;fullyLoaded=false;publicTones=[];soundOn=true;notifyPublicTrade({id:'ARBITRUM:offchart-live',net:'ARBITRUM',pair:1,long:false,lev:50,amount:10,entry:2600},'open')});
 assert.equal(await page.locator('#tradeEvent').textContent(),btcBanner);assert.equal(await page.evaluate(()=>publicTones.length),0);
 await page.evaluate(()=>{pair=1;render()});assert((await page.locator('#tradeEvent').textContent()).includes('ETH / USD'));assert.equal(await page.evaluate(()=>publicTones.length),0);await page.evaluate(()=>{pair=0;render()});assert.equal(await page.locator('#tradeEvent').textContent(),btcBanner);
 await page.evaluate(()=>{fullyLoaded=true;clearTradeEvent();publicTones=[];seedLatestPublicTrade([{date:new Date(Date.now()-60000).toISOString(),pair:'BTC/USD',address:'browser-seed',tradeIndex:1,action:'TradeClosedLIQ',long:0,leverage:50,size:10,price:2600,net:'BASE'}])});
 assert((await page.locator('#tradeEvent').textContent()).includes('Last confirmed'));assert((await page.locator('#tradeEvent').textContent()).includes('LIQ S'));assert.equal(await page.evaluate(()=>publicTones.length),0,'historical startup text remains silent');
 await page.evaluate(()=>checkpointSession());const lastBanner=await page.locator('#tradeEvent').textContent();await page.reload();await page.waitForTimeout(800);assert.equal(await page.locator('#tradeEvent').textContent(),lastBanner,'last event restored after recreation');assert.equal(await page.locator('#tradeEvent').isVisible(),true);
 // Upgrade discards legacy unscoped text; cached other-market events cannot restore on BTC.
 await page.evaluate(()=>{const session=JSON.parse(localStorage.getItem('chartSession'));session.lastTradeEvents=[{text:'FET CLOSE L',action:'close',long:true,at:Date.now(),pair:6}];session.lastTradeEvent={text:'OLD FET OPEN L',action:'open',long:true,at:Date.now()};localStorage.setItem('chartSession',JSON.stringify(session))});await page.reload();await page.waitForTimeout(800);assert(!(await page.locator('#tradeEvent').textContent()).includes('FET'),'recreation rejects unrelated and legacy unscoped text');
 await page.screenshot({path:'build/mobile-qa.png'});assert.deepEqual(errors,[]);console.log('PASS: standalone HTML loads, paper long renders, settings works, repeated portrait/landscape rotations keep controls inside viewport, no script errors or horizontal overflow.');await browser.close();
})().catch(e=>{console.error(e);process.exit(1)});
